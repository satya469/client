self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ab001499e38fb86b4b24d7f3abf82f1c",
    "url": "/index.html"
  },
  {
    "revision": "f08bfb3de7f8690f45cd",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "1127ff52f65b747386e7",
    "url": "/static/css/11.2e947bf2.chunk.css"
  },
  {
    "revision": "77b4aceedd7fbfa9dd8a",
    "url": "/static/css/12.16f755ee.chunk.css"
  },
  {
    "revision": "c56b6d310f9abe5d94c4",
    "url": "/static/css/13.ac09eb94.chunk.css"
  },
  {
    "revision": "ffcffc38d52653801777",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "f08bfb3de7f8690f45cd",
    "url": "/static/js/0.e0cec191.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.e0cec191.chunk.js.LICENSE.txt"
  },
  {
    "revision": "af178ad75ef0330d1465",
    "url": "/static/js/1.fb4849f7.chunk.js"
  },
  {
    "revision": "1127ff52f65b747386e7",
    "url": "/static/js/11.d8b1c5d9.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/11.d8b1c5d9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "77b4aceedd7fbfa9dd8a",
    "url": "/static/js/12.6ec95e94.chunk.js"
  },
  {
    "revision": "c56b6d310f9abe5d94c4",
    "url": "/static/js/13.2ea01a09.chunk.js"
  },
  {
    "revision": "93139614078c008fa622",
    "url": "/static/js/14.31b39bde.chunk.js"
  },
  {
    "revision": "3ae4d2298eb591698eef",
    "url": "/static/js/15.0c613980.chunk.js"
  },
  {
    "revision": "5fe56a9b4c9dcc8709f5",
    "url": "/static/js/16.db9203c5.chunk.js"
  },
  {
    "revision": "ee97a192deede3d681e9",
    "url": "/static/js/17.cdcfc6c2.chunk.js"
  },
  {
    "revision": "e747186a61cb303539e7",
    "url": "/static/js/18.f7d61d0b.chunk.js"
  },
  {
    "revision": "3c068cfd90116b2ae55a",
    "url": "/static/js/19.801f43b5.chunk.js"
  },
  {
    "revision": "0865173844708a39cf1b",
    "url": "/static/js/2.02aa95b2.chunk.js"
  },
  {
    "revision": "851d290aed66f1c44201",
    "url": "/static/js/20.0af96d42.chunk.js"
  },
  {
    "revision": "a4883f5a62a3b95a0fc8",
    "url": "/static/js/21.932dc6fc.chunk.js"
  },
  {
    "revision": "56fc4b4c00fd28f45004",
    "url": "/static/js/22.83453d19.chunk.js"
  },
  {
    "revision": "ba72da2f59cd2e942461",
    "url": "/static/js/23.e3c080dd.chunk.js"
  },
  {
    "revision": "546f02bd2a7720f46894",
    "url": "/static/js/24.b82c47be.chunk.js"
  },
  {
    "revision": "59e4ce1388fe3f6b1a3f",
    "url": "/static/js/25.e33591ea.chunk.js"
  },
  {
    "revision": "ff2f4a2898bbe5dde0be",
    "url": "/static/js/26.2b2762af.chunk.js"
  },
  {
    "revision": "b3b364d9ec192899825d",
    "url": "/static/js/27.70453e44.chunk.js"
  },
  {
    "revision": "b81283673170959ab59e",
    "url": "/static/js/28.027fdf65.chunk.js"
  },
  {
    "revision": "9443f8c53d40fa9d5044",
    "url": "/static/js/29.5779890f.chunk.js"
  },
  {
    "revision": "fe996b3f62d7b0ad0c69",
    "url": "/static/js/3.15ea48c2.chunk.js"
  },
  {
    "revision": "9899cd50f3828146850b",
    "url": "/static/js/30.0f50780d.chunk.js"
  },
  {
    "revision": "da350a0a481c1c7310d0",
    "url": "/static/js/31.491b0b58.chunk.js"
  },
  {
    "revision": "9707e31c3aae810c9abf",
    "url": "/static/js/32.bac3bfc4.chunk.js"
  },
  {
    "revision": "9d59ed37b57b9299d3e1",
    "url": "/static/js/33.21574ee0.chunk.js"
  },
  {
    "revision": "237c9ab62b8fe61bc053",
    "url": "/static/js/34.ba76b92d.chunk.js"
  },
  {
    "revision": "0d034ca3f0413f35f6d5",
    "url": "/static/js/35.461cd22e.chunk.js"
  },
  {
    "revision": "587550969af68445401a",
    "url": "/static/js/36.26a8041b.chunk.js"
  },
  {
    "revision": "5ed96985e45d4ae01d86",
    "url": "/static/js/37.157cf7c3.chunk.js"
  },
  {
    "revision": "4a40b0fe966a6bce57d8",
    "url": "/static/js/38.b2e65ec3.chunk.js"
  },
  {
    "revision": "a34e4ffc5a6d382b9db7",
    "url": "/static/js/39.31c7db75.chunk.js"
  },
  {
    "revision": "b7c0acaf04285a9c29c4",
    "url": "/static/js/4.42c1df58.chunk.js"
  },
  {
    "revision": "a2431671ca92666e962f",
    "url": "/static/js/40.2ea9e96b.chunk.js"
  },
  {
    "revision": "002966219b7e1ddbc507",
    "url": "/static/js/41.0a8eeb04.chunk.js"
  },
  {
    "revision": "fa7361d3fc0252671845",
    "url": "/static/js/42.93397ef9.chunk.js"
  },
  {
    "revision": "5661a5653023a4f3d22a",
    "url": "/static/js/43.a765f885.chunk.js"
  },
  {
    "revision": "4ff653d85040fc2969f6",
    "url": "/static/js/44.453d272c.chunk.js"
  },
  {
    "revision": "7ecc62eaa1832ea447f6",
    "url": "/static/js/45.91a1ffa9.chunk.js"
  },
  {
    "revision": "348a1f3fd31a54b8865c",
    "url": "/static/js/46.c7fb25e3.chunk.js"
  },
  {
    "revision": "a65c8151445712ee9863",
    "url": "/static/js/47.d9d28a2a.chunk.js"
  },
  {
    "revision": "8235672fafecf33bb296",
    "url": "/static/js/48.9403b7dd.chunk.js"
  },
  {
    "revision": "9158683d1d54bbff09fa",
    "url": "/static/js/49.79b0a23d.chunk.js"
  },
  {
    "revision": "156905716c0aff5cab2f",
    "url": "/static/js/5.8ec6920d.chunk.js"
  },
  {
    "revision": "48deda5ac3094e2617f2",
    "url": "/static/js/50.703c0b0c.chunk.js"
  },
  {
    "revision": "f928b5b9213211c5e5c8",
    "url": "/static/js/51.be0f90c2.chunk.js"
  },
  {
    "revision": "85587e453b5b58981ec3",
    "url": "/static/js/52.ac9594cf.chunk.js"
  },
  {
    "revision": "1d01406693c1696d661b",
    "url": "/static/js/53.141ee64d.chunk.js"
  },
  {
    "revision": "1e85e13dfa4f32f6e2bf",
    "url": "/static/js/54.e2441b1f.chunk.js"
  },
  {
    "revision": "9cdab496e21a2d2f024a",
    "url": "/static/js/55.c3f5cf83.chunk.js"
  },
  {
    "revision": "fee2865beee071166ece",
    "url": "/static/js/56.df990d84.chunk.js"
  },
  {
    "revision": "24463df6bce57834c560",
    "url": "/static/js/57.c2bec197.chunk.js"
  },
  {
    "revision": "23034da2aea1045d7af3",
    "url": "/static/js/58.32f2395e.chunk.js"
  },
  {
    "revision": "b48fb75fe8d3cee14326",
    "url": "/static/js/59.2072e9d2.chunk.js"
  },
  {
    "revision": "a0da535705a294d74e13",
    "url": "/static/js/6.1b8ce047.chunk.js"
  },
  {
    "revision": "6e3265b0f43172f1aa3c",
    "url": "/static/js/60.9b5bb34c.chunk.js"
  },
  {
    "revision": "523004ef773de62bb049",
    "url": "/static/js/61.5f6a19f5.chunk.js"
  },
  {
    "revision": "86db5642fb7e03244899",
    "url": "/static/js/62.7043127d.chunk.js"
  },
  {
    "revision": "01c71a7509557276e954",
    "url": "/static/js/63.fbdd7127.chunk.js"
  },
  {
    "revision": "06b7161e629e2bee6c03",
    "url": "/static/js/64.1dd2b2f8.chunk.js"
  },
  {
    "revision": "ee6761071511b371de6d",
    "url": "/static/js/65.a19e155a.chunk.js"
  },
  {
    "revision": "e89e01af04b5d80372e8",
    "url": "/static/js/66.ca995248.chunk.js"
  },
  {
    "revision": "07faf2c49c057cd50318",
    "url": "/static/js/67.dc88b64a.chunk.js"
  },
  {
    "revision": "5d7035471dbdbbfa459c",
    "url": "/static/js/68.342a2e5d.chunk.js"
  },
  {
    "revision": "7cd17cd85c4d120e118b",
    "url": "/static/js/69.a00712a4.chunk.js"
  },
  {
    "revision": "8292a1c0236c38da2f7c",
    "url": "/static/js/7.867a24d9.chunk.js"
  },
  {
    "revision": "cbb2df7b847f8714ead3",
    "url": "/static/js/70.52dc1e29.chunk.js"
  },
  {
    "revision": "b03bac5c272306d0546d",
    "url": "/static/js/71.e2d94938.chunk.js"
  },
  {
    "revision": "baf7297d4cf4df6a8928",
    "url": "/static/js/72.13c29efd.chunk.js"
  },
  {
    "revision": "ece3721b3665013957b5",
    "url": "/static/js/73.90fdb74f.chunk.js"
  },
  {
    "revision": "104b943609ec98bc7916",
    "url": "/static/js/74.06d2fbef.chunk.js"
  },
  {
    "revision": "375e8490a03444034ef8",
    "url": "/static/js/75.55a608a8.chunk.js"
  },
  {
    "revision": "fd2e5447eb094794a603",
    "url": "/static/js/76.b541c228.chunk.js"
  },
  {
    "revision": "28d9b2f2f72c6a3ab6ed",
    "url": "/static/js/8.5748691a.chunk.js"
  },
  {
    "revision": "ffcffc38d52653801777",
    "url": "/static/js/main.317f0234.chunk.js"
  },
  {
    "revision": "602b22d6d8d3fbdc063a",
    "url": "/static/js/runtime-main.40d17ce1.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);