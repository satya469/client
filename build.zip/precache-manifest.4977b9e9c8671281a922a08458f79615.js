self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "844c22c4f68934e34e6f49757ee3507b",
    "url": "/index.html"
  },
  {
    "revision": "abe3357199b4b6365aa9",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "d0ecf5c55fdb98f6c47c",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "93e9adf5220a5cc55601",
    "url": "/static/css/14.a5a171c3.chunk.css"
  },
  {
    "revision": "e1fd576e1946871014a9",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "bdd00d4ddb6859a41f95",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "abe3357199b4b6365aa9",
    "url": "/static/js/0.3ce00143.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.3ce00143.chunk.js.LICENSE.txt"
  },
  {
    "revision": "33c1316357229581f6d0",
    "url": "/static/js/1.3d44cf34.chunk.js"
  },
  {
    "revision": "ac104c3e2dd6e02cb366",
    "url": "/static/js/10.3192a3a2.chunk.js"
  },
  {
    "revision": "d0ecf5c55fdb98f6c47c",
    "url": "/static/js/13.e611c78e.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.e611c78e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "93e9adf5220a5cc55601",
    "url": "/static/js/14.7450a96d.chunk.js"
  },
  {
    "revision": "e1fd576e1946871014a9",
    "url": "/static/js/15.206ebb76.chunk.js"
  },
  {
    "revision": "f2a36d4efc00cb613627",
    "url": "/static/js/16.45508204.chunk.js"
  },
  {
    "revision": "b79eaa32166465b8066a",
    "url": "/static/js/17.5e144f11.chunk.js"
  },
  {
    "revision": "4aafa24d0491f8a62f8c",
    "url": "/static/js/18.f5291135.chunk.js"
  },
  {
    "revision": "e1d5adac9962c0a65bf5",
    "url": "/static/js/19.123e644d.chunk.js"
  },
  {
    "revision": "7948250f7b32dec87e44",
    "url": "/static/js/2.93b5f01c.chunk.js"
  },
  {
    "revision": "51e99651b44a3cd6ff86",
    "url": "/static/js/20.70f89ce2.chunk.js"
  },
  {
    "revision": "a7809038faa8b8a5e7ed",
    "url": "/static/js/21.8691f97c.chunk.js"
  },
  {
    "revision": "d1de3cb9d75b7547facc",
    "url": "/static/js/22.eed7de7e.chunk.js"
  },
  {
    "revision": "941715f1ec7de2d271be",
    "url": "/static/js/23.5aedfc4e.chunk.js"
  },
  {
    "revision": "8651a5a56c8ef82c836a",
    "url": "/static/js/24.6ce7e212.chunk.js"
  },
  {
    "revision": "b7df8ee7e51f8da77617",
    "url": "/static/js/25.28724e5c.chunk.js"
  },
  {
    "revision": "d63215dccc23256d95d3",
    "url": "/static/js/26.4d594a8b.chunk.js"
  },
  {
    "revision": "be6bd3c2d1d769276d02",
    "url": "/static/js/27.8b794521.chunk.js"
  },
  {
    "revision": "8e1c11eae3f0318a0758",
    "url": "/static/js/28.bdd2e402.chunk.js"
  },
  {
    "revision": "f642c362bb7f4ba31705",
    "url": "/static/js/29.edc38b62.chunk.js"
  },
  {
    "revision": "60e567f5f7df03f2d671",
    "url": "/static/js/3.4d38fd0a.chunk.js"
  },
  {
    "revision": "5a06189cd0824790fb2e",
    "url": "/static/js/30.acbe3d29.chunk.js"
  },
  {
    "revision": "8a8472a45e58943f1dfb",
    "url": "/static/js/31.24a1e7f0.chunk.js"
  },
  {
    "revision": "c9701bab831fc3965ee0",
    "url": "/static/js/32.86685d41.chunk.js"
  },
  {
    "revision": "5f363c563d6d90dc8151",
    "url": "/static/js/33.7a5dcf08.chunk.js"
  },
  {
    "revision": "1eb3f73e6ad0c0f2437a",
    "url": "/static/js/34.8a766770.chunk.js"
  },
  {
    "revision": "59bee37c5fd0e76828e2",
    "url": "/static/js/35.4d34d939.chunk.js"
  },
  {
    "revision": "185b097bfb44f3ca4b86",
    "url": "/static/js/36.17cab21e.chunk.js"
  },
  {
    "revision": "e1d3e4f676e06fc131ac",
    "url": "/static/js/37.9e0cad91.chunk.js"
  },
  {
    "revision": "b49475020f9122853565",
    "url": "/static/js/38.3d607e79.chunk.js"
  },
  {
    "revision": "fc2d9f1cdf3d1364909d",
    "url": "/static/js/39.8edcb01b.chunk.js"
  },
  {
    "revision": "1171b3f8beba92785bf0",
    "url": "/static/js/4.cd58e785.chunk.js"
  },
  {
    "revision": "3100a8bfdbd34943c367",
    "url": "/static/js/40.03066619.chunk.js"
  },
  {
    "revision": "6843c5bb5474c64efeb4",
    "url": "/static/js/41.80e3c5eb.chunk.js"
  },
  {
    "revision": "9ab4421976f892331cca",
    "url": "/static/js/42.e8ebf0ed.chunk.js"
  },
  {
    "revision": "497512b007e6766e8230",
    "url": "/static/js/43.66dbf65a.chunk.js"
  },
  {
    "revision": "633dc5139dfe63cc1c31",
    "url": "/static/js/44.29145919.chunk.js"
  },
  {
    "revision": "2334a09300bcca627787",
    "url": "/static/js/45.356aa821.chunk.js"
  },
  {
    "revision": "25f8a25bca5f7701514a",
    "url": "/static/js/46.f6ed4fc8.chunk.js"
  },
  {
    "revision": "7b0a9ba435e972fa69af",
    "url": "/static/js/47.553d9494.chunk.js"
  },
  {
    "revision": "9c2b586925a60a712d53",
    "url": "/static/js/48.798d099a.chunk.js"
  },
  {
    "revision": "2223d51f40aecf2d4fbe",
    "url": "/static/js/49.e0dc2ed4.chunk.js"
  },
  {
    "revision": "cb492732fb3309ee6f6c",
    "url": "/static/js/5.ad17f7e3.chunk.js"
  },
  {
    "revision": "419f6528ee7b51078e51",
    "url": "/static/js/50.041e4958.chunk.js"
  },
  {
    "revision": "1410d917a4710fe4709e",
    "url": "/static/js/51.1818de43.chunk.js"
  },
  {
    "revision": "0c152a0559e8b169298a",
    "url": "/static/js/52.c34d8bfd.chunk.js"
  },
  {
    "revision": "687e1712e47ef8aea21c",
    "url": "/static/js/53.171a41ba.chunk.js"
  },
  {
    "revision": "e2b8ec16ae5d489dfa29",
    "url": "/static/js/54.cf21f78d.chunk.js"
  },
  {
    "revision": "5e3b3fdb43235a0fb3b1",
    "url": "/static/js/55.e9e5a223.chunk.js"
  },
  {
    "revision": "4e80ca6a76d1481af476",
    "url": "/static/js/56.baece19a.chunk.js"
  },
  {
    "revision": "e2b1a7b78c9447c508db",
    "url": "/static/js/57.7e3c7e0f.chunk.js"
  },
  {
    "revision": "0d3392929918947c91fd",
    "url": "/static/js/58.f981c649.chunk.js"
  },
  {
    "revision": "deb8da716f01dd9fca55",
    "url": "/static/js/59.a0751437.chunk.js"
  },
  {
    "revision": "d45b7430907f86f41f99",
    "url": "/static/js/6.10eeed3f.chunk.js"
  },
  {
    "revision": "23ee8ec617c1fc88ec9b",
    "url": "/static/js/60.17475210.chunk.js"
  },
  {
    "revision": "ce3a85a33b2a699bc068",
    "url": "/static/js/61.d42e6ca4.chunk.js"
  },
  {
    "revision": "8eedae0c98b734443ae1",
    "url": "/static/js/62.3bfae98b.chunk.js"
  },
  {
    "revision": "255853240305213a96d5",
    "url": "/static/js/63.aba25351.chunk.js"
  },
  {
    "revision": "c0bbb01265cd8552ab18",
    "url": "/static/js/64.99bb8ecf.chunk.js"
  },
  {
    "revision": "329613547c5c7145c7ae",
    "url": "/static/js/65.25e9a69f.chunk.js"
  },
  {
    "revision": "a7970a657c95f37f26c8",
    "url": "/static/js/66.44848df3.chunk.js"
  },
  {
    "revision": "74a837569973bd856d62",
    "url": "/static/js/67.e40cebcb.chunk.js"
  },
  {
    "revision": "9ab971c797bb5d22a707",
    "url": "/static/js/68.6a8e2ab3.chunk.js"
  },
  {
    "revision": "45dacfbd31a80eba22b8",
    "url": "/static/js/69.c2ae0bdc.chunk.js"
  },
  {
    "revision": "6f91751fac89d74d0f46",
    "url": "/static/js/7.974627ba.chunk.js"
  },
  {
    "revision": "02b3a4a996a06a983802",
    "url": "/static/js/70.078ce854.chunk.js"
  },
  {
    "revision": "f02909b47e396bc2c444",
    "url": "/static/js/71.94aec55d.chunk.js"
  },
  {
    "revision": "504953b8153ec5ec0e64",
    "url": "/static/js/72.37a80565.chunk.js"
  },
  {
    "revision": "88e0abfdbe338f363954",
    "url": "/static/js/73.d4c59c3c.chunk.js"
  },
  {
    "revision": "42a59e566dcce97d1e5a",
    "url": "/static/js/74.b242c788.chunk.js"
  },
  {
    "revision": "0f39a09f06d95d1f27c4",
    "url": "/static/js/75.51cf58f9.chunk.js"
  },
  {
    "revision": "c7625fde4c4b68af1b5d",
    "url": "/static/js/76.10f98125.chunk.js"
  },
  {
    "revision": "280cf6a0f43d3332438c",
    "url": "/static/js/77.1681a63d.chunk.js"
  },
  {
    "revision": "213edd82978a0e8666cf",
    "url": "/static/js/8.81af8d9d.chunk.js"
  },
  {
    "revision": "4884506f8ed4cbd14409",
    "url": "/static/js/9.5420ced3.chunk.js"
  },
  {
    "revision": "bdd00d4ddb6859a41f95",
    "url": "/static/js/main.a639a793.chunk.js"
  },
  {
    "revision": "1ec7cb8556f032348d85",
    "url": "/static/js/runtime-main.af284f90.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);