self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c74195cf7ff59baab83effb10a19aaa1",
    "url": "/index.html"
  },
  {
    "revision": "0c795a43605ae019be60",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "b09524ab73a8a9eef5c1",
    "url": "/static/css/14.2e947bf2.chunk.css"
  },
  {
    "revision": "399ee37e4ab37195b19f",
    "url": "/static/css/15.f83fd0f9.chunk.css"
  },
  {
    "revision": "5506b1a0f03601192970",
    "url": "/static/css/16.ac09eb94.chunk.css"
  },
  {
    "revision": "99a030481a08b6e00664",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "0c795a43605ae019be60",
    "url": "/static/js/0.f41c0ef0.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.f41c0ef0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "67cecdbe359f93933295",
    "url": "/static/js/1.c755569d.chunk.js"
  },
  {
    "revision": "33ab2c2a190ed5eb55a8",
    "url": "/static/js/10.31bad309.chunk.js"
  },
  {
    "revision": "18d6312f3689fde18158",
    "url": "/static/js/11.94569b2f.chunk.js"
  },
  {
    "revision": "b09524ab73a8a9eef5c1",
    "url": "/static/js/14.ca19482f.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/14.ca19482f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "399ee37e4ab37195b19f",
    "url": "/static/js/15.3270ccc6.chunk.js"
  },
  {
    "revision": "5506b1a0f03601192970",
    "url": "/static/js/16.f15a0d88.chunk.js"
  },
  {
    "revision": "b1c12e8e44f6de9f2edf",
    "url": "/static/js/17.4f09df32.chunk.js"
  },
  {
    "revision": "1643a60bfa5f48019541",
    "url": "/static/js/18.ecacfd94.chunk.js"
  },
  {
    "revision": "f5ed54f42cde956c5e0d",
    "url": "/static/js/19.37a900b0.chunk.js"
  },
  {
    "revision": "b08b7fe41d58d394d685",
    "url": "/static/js/2.da1fe974.chunk.js"
  },
  {
    "revision": "e171082824b4b7b626b9",
    "url": "/static/js/20.8d779052.chunk.js"
  },
  {
    "revision": "274f675f681db4377a4b",
    "url": "/static/js/21.bbc81212.chunk.js"
  },
  {
    "revision": "a4f582c2ea6483822d48",
    "url": "/static/js/22.d2e16587.chunk.js"
  },
  {
    "revision": "2c5aee16346f8591cf5a",
    "url": "/static/js/23.c9512c08.chunk.js"
  },
  {
    "revision": "3c60e39542383a1edaa9",
    "url": "/static/js/24.e9f575d5.chunk.js"
  },
  {
    "revision": "08aa2df75a405e009c15",
    "url": "/static/js/25.4ea06875.chunk.js"
  },
  {
    "revision": "980d092cdb2084425f7b",
    "url": "/static/js/26.c47418f0.chunk.js"
  },
  {
    "revision": "9dd8076152facff00b30",
    "url": "/static/js/27.e47b82fe.chunk.js"
  },
  {
    "revision": "3b7cd92ea1ce7f8b1ebc",
    "url": "/static/js/28.669ab3c2.chunk.js"
  },
  {
    "revision": "5f039682187b36ea6a3e",
    "url": "/static/js/29.9b4ab721.chunk.js"
  },
  {
    "revision": "c8052ec10b18bc5efe4d",
    "url": "/static/js/3.de5b531b.chunk.js"
  },
  {
    "revision": "aab9578ec09b7b06b505",
    "url": "/static/js/30.f12a9aff.chunk.js"
  },
  {
    "revision": "99fd2e78531c2838bd4a",
    "url": "/static/js/31.01882c09.chunk.js"
  },
  {
    "revision": "38a50ae347fffa293add",
    "url": "/static/js/32.353fdde7.chunk.js"
  },
  {
    "revision": "0f2778c0b192bb3e1328",
    "url": "/static/js/33.cc60b2af.chunk.js"
  },
  {
    "revision": "6e59fdaac1c97c03cd50",
    "url": "/static/js/34.aaa582bd.chunk.js"
  },
  {
    "revision": "789bce044d06be3eb748",
    "url": "/static/js/35.54e181dc.chunk.js"
  },
  {
    "revision": "aa7bad032a9694d5c086",
    "url": "/static/js/36.989ee621.chunk.js"
  },
  {
    "revision": "da233d84a80e1341d0ab",
    "url": "/static/js/37.9ce024a2.chunk.js"
  },
  {
    "revision": "a7e5be9a74ba61302837",
    "url": "/static/js/38.2c3a51b8.chunk.js"
  },
  {
    "revision": "e11fb6f66f57af84f1af",
    "url": "/static/js/39.9d97d03f.chunk.js"
  },
  {
    "revision": "0a2f3d68ecd8efff39a9",
    "url": "/static/js/4.f54c94eb.chunk.js"
  },
  {
    "revision": "4cc6c984e5aa56d70a8b",
    "url": "/static/js/40.aadcd2de.chunk.js"
  },
  {
    "revision": "6615705261c8dbb6522b",
    "url": "/static/js/41.8c5f83b8.chunk.js"
  },
  {
    "revision": "c3a1806db3ec22212e44",
    "url": "/static/js/42.68a9b136.chunk.js"
  },
  {
    "revision": "063d7bd86601b2dd8aed",
    "url": "/static/js/43.65248657.chunk.js"
  },
  {
    "revision": "b472c7170575066e1227",
    "url": "/static/js/44.e2b82330.chunk.js"
  },
  {
    "revision": "6aff4713386807d2648b",
    "url": "/static/js/45.fbba43cb.chunk.js"
  },
  {
    "revision": "3e0c569bbbd30433fd7f",
    "url": "/static/js/46.71ce2cb7.chunk.js"
  },
  {
    "revision": "b300f7c1f9b93dd5ec77",
    "url": "/static/js/47.0e1cf3f7.chunk.js"
  },
  {
    "revision": "5ba58a12be680da70158",
    "url": "/static/js/48.f2c0d7ad.chunk.js"
  },
  {
    "revision": "1e49c1f8955e6d65c777",
    "url": "/static/js/49.bc6f8d5f.chunk.js"
  },
  {
    "revision": "9a0cfed559636d472eaf",
    "url": "/static/js/5.0cb6ba48.chunk.js"
  },
  {
    "revision": "ede3c5da804b2b6d9351",
    "url": "/static/js/50.b2c45a09.chunk.js"
  },
  {
    "revision": "ba67e20c039b85f85d9f",
    "url": "/static/js/51.086145b8.chunk.js"
  },
  {
    "revision": "1f444f4831886b1c7ac1",
    "url": "/static/js/52.3a792b7e.chunk.js"
  },
  {
    "revision": "47b032d641655ad54292",
    "url": "/static/js/53.2e1cd9c0.chunk.js"
  },
  {
    "revision": "9d9e0d7e2e88cf5a5f85",
    "url": "/static/js/54.0418a423.chunk.js"
  },
  {
    "revision": "410641f998fe0d3d2128",
    "url": "/static/js/55.8a853593.chunk.js"
  },
  {
    "revision": "74ab6ffa2d706fc5ab6e",
    "url": "/static/js/56.b0c4a901.chunk.js"
  },
  {
    "revision": "9a155f250eb5ca41fc2a",
    "url": "/static/js/57.df157198.chunk.js"
  },
  {
    "revision": "dc6da9fa91bd7fe94adf",
    "url": "/static/js/58.59807dc1.chunk.js"
  },
  {
    "revision": "c302a2a90a2a48fe5aae",
    "url": "/static/js/59.c1d7c9d7.chunk.js"
  },
  {
    "revision": "99297bc1bd3d4ceccb21",
    "url": "/static/js/6.8ffbcaeb.chunk.js"
  },
  {
    "revision": "27ad4be423eeea7bc5f7",
    "url": "/static/js/60.6d522552.chunk.js"
  },
  {
    "revision": "8e81b3f2a0c360d27471",
    "url": "/static/js/61.544bc08e.chunk.js"
  },
  {
    "revision": "c2ddbd599ffa74833677",
    "url": "/static/js/62.d7c4c554.chunk.js"
  },
  {
    "revision": "78e0563e36ffe5f83bdf",
    "url": "/static/js/63.7e19a8a1.chunk.js"
  },
  {
    "revision": "bfef8febba6a4bca3c85",
    "url": "/static/js/64.8190e5a6.chunk.js"
  },
  {
    "revision": "c2f799e678333bc1da35",
    "url": "/static/js/65.9fc10702.chunk.js"
  },
  {
    "revision": "9809c1cf1decf0f3f5b0",
    "url": "/static/js/66.478d88bf.chunk.js"
  },
  {
    "revision": "a44bc15739e6328ab027",
    "url": "/static/js/67.433ec965.chunk.js"
  },
  {
    "revision": "5d172632e8ce1bd080f6",
    "url": "/static/js/68.b2058140.chunk.js"
  },
  {
    "revision": "de3b44a53c81206a7ea6",
    "url": "/static/js/69.43826089.chunk.js"
  },
  {
    "revision": "5c086b1460c010cdf912",
    "url": "/static/js/7.3aee95bb.chunk.js"
  },
  {
    "revision": "6ee403ebc6c443885cf3",
    "url": "/static/js/70.bb4740e9.chunk.js"
  },
  {
    "revision": "ab9c7cdc57cdaa4c4a21",
    "url": "/static/js/71.223a8115.chunk.js"
  },
  {
    "revision": "dbfaab39c4406a69ef77",
    "url": "/static/js/72.a68957f6.chunk.js"
  },
  {
    "revision": "dc6d1e38b8142e03994f",
    "url": "/static/js/73.90040641.chunk.js"
  },
  {
    "revision": "823c07586586a654c9c0",
    "url": "/static/js/74.034b46a8.chunk.js"
  },
  {
    "revision": "651fa38c8f698cc1d022",
    "url": "/static/js/75.e047b491.chunk.js"
  },
  {
    "revision": "83967e7ada695af18aa9",
    "url": "/static/js/76.014aed1f.chunk.js"
  },
  {
    "revision": "4ec76147f62afd679513",
    "url": "/static/js/77.9bd3306d.chunk.js"
  },
  {
    "revision": "6aaf22279b1e590b03f5",
    "url": "/static/js/78.9a830028.chunk.js"
  },
  {
    "revision": "549371d68e34ae8dd97c",
    "url": "/static/js/79.e1765600.chunk.js"
  },
  {
    "revision": "32ac1b3a6c90925b86b4",
    "url": "/static/js/8.743dccff.chunk.js"
  },
  {
    "revision": "ca09b77bf13cec11fee0",
    "url": "/static/js/80.a2978290.chunk.js"
  },
  {
    "revision": "0504106eb79d898f1b5e",
    "url": "/static/js/81.640d11d9.chunk.js"
  },
  {
    "revision": "29cbeaa0bbfa3cd1d4c7",
    "url": "/static/js/82.2ce1ba5a.chunk.js"
  },
  {
    "revision": "cdbcad2d996d213c4595",
    "url": "/static/js/9.b7662914.chunk.js"
  },
  {
    "revision": "99a030481a08b6e00664",
    "url": "/static/js/main.68fe8f60.chunk.js"
  },
  {
    "revision": "a511045496818eeff077",
    "url": "/static/js/runtime-main.805137dd.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);