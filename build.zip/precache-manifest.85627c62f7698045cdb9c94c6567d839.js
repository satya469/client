self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2f9528b8e4db8c2fad604da21a51e084",
    "url": "/index.html"
  },
  {
    "revision": "16923500191e3244ea9b",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "b2ae3233bd345674bf41",
    "url": "/static/css/12.2e947bf2.chunk.css"
  },
  {
    "revision": "55f7216596b6d7eb9a24",
    "url": "/static/css/13.e7914115.chunk.css"
  },
  {
    "revision": "7d1cb1d64a06e944085a",
    "url": "/static/css/14.834d426e.chunk.css"
  },
  {
    "revision": "263abd1488e213a5605d",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "16923500191e3244ea9b",
    "url": "/static/js/0.e4746f18.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.e4746f18.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c421df838c7c3dc04f5b",
    "url": "/static/js/1.6b3ee22d.chunk.js"
  },
  {
    "revision": "b2ae3233bd345674bf41",
    "url": "/static/js/12.d942c130.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/12.d942c130.chunk.js.LICENSE.txt"
  },
  {
    "revision": "55f7216596b6d7eb9a24",
    "url": "/static/js/13.f4535d19.chunk.js"
  },
  {
    "revision": "7d1cb1d64a06e944085a",
    "url": "/static/js/14.6c9aa6b9.chunk.js"
  },
  {
    "revision": "1077c2498e0990db9fa0",
    "url": "/static/js/15.86a05309.chunk.js"
  },
  {
    "revision": "578f05c5e982c176e63b",
    "url": "/static/js/16.1b656f9f.chunk.js"
  },
  {
    "revision": "73acb4a4447271eeda54",
    "url": "/static/js/17.3ed47dc8.chunk.js"
  },
  {
    "revision": "3e1e459bdbdfe5cd75ae",
    "url": "/static/js/18.47d3d68e.chunk.js"
  },
  {
    "revision": "0d6aafbc9702c9a9cc64",
    "url": "/static/js/19.e1684025.chunk.js"
  },
  {
    "revision": "a6af051a3bc96da2bb0e",
    "url": "/static/js/2.026da372.chunk.js"
  },
  {
    "revision": "165340fd4ffe74b26564",
    "url": "/static/js/20.94f62790.chunk.js"
  },
  {
    "revision": "1b44b6f529414ac8c7e1",
    "url": "/static/js/21.081c9bb8.chunk.js"
  },
  {
    "revision": "9d0bbf58c83be09d86ac",
    "url": "/static/js/22.75b22836.chunk.js"
  },
  {
    "revision": "678ece25bb8ba9ea13fb",
    "url": "/static/js/23.43a09ea3.chunk.js"
  },
  {
    "revision": "39da14f111830c4f6b71",
    "url": "/static/js/24.78628177.chunk.js"
  },
  {
    "revision": "cf5858e676a3dad63967",
    "url": "/static/js/25.ee7f89ff.chunk.js"
  },
  {
    "revision": "a3b5d589827b4d230306",
    "url": "/static/js/26.fe21def1.chunk.js"
  },
  {
    "revision": "c9861b0d449f94e5c337",
    "url": "/static/js/27.411c9438.chunk.js"
  },
  {
    "revision": "7d71ad6118cc47308c06",
    "url": "/static/js/28.b40b2c70.chunk.js"
  },
  {
    "revision": "1809584dd9ba9234a5eb",
    "url": "/static/js/29.c3247ca5.chunk.js"
  },
  {
    "revision": "915f62e67f1acfcae34e",
    "url": "/static/js/3.c1b9ff02.chunk.js"
  },
  {
    "revision": "313e6e85bb1f80e690a4",
    "url": "/static/js/30.9e372f90.chunk.js"
  },
  {
    "revision": "3171f89c4d7e17c9caea",
    "url": "/static/js/31.6ee88323.chunk.js"
  },
  {
    "revision": "bfc54ab21626a99d4acd",
    "url": "/static/js/32.2c9687c1.chunk.js"
  },
  {
    "revision": "ac3b2d34ccddf824ffcd",
    "url": "/static/js/33.172a94cb.chunk.js"
  },
  {
    "revision": "44e3be6aeab3a0c1b6eb",
    "url": "/static/js/34.5561c70f.chunk.js"
  },
  {
    "revision": "743ed52abc9f0805f02b",
    "url": "/static/js/35.87646e93.chunk.js"
  },
  {
    "revision": "028a67ca69e7d0048dfb",
    "url": "/static/js/36.d1454a8d.chunk.js"
  },
  {
    "revision": "919e350e23eb4bdfa4da",
    "url": "/static/js/37.66916a41.chunk.js"
  },
  {
    "revision": "d9778e4cfb9e3b79c7a8",
    "url": "/static/js/38.95238422.chunk.js"
  },
  {
    "revision": "dec6265e61614ea261d0",
    "url": "/static/js/39.6d6846f6.chunk.js"
  },
  {
    "revision": "5d234f2d7400b6fc0edd",
    "url": "/static/js/4.52a20ca4.chunk.js"
  },
  {
    "revision": "5df7851dc14c168d8732",
    "url": "/static/js/40.0518310e.chunk.js"
  },
  {
    "revision": "f86021edb4ec143f49fc",
    "url": "/static/js/41.fe277624.chunk.js"
  },
  {
    "revision": "9589201b63d599f73f70",
    "url": "/static/js/42.64a008ec.chunk.js"
  },
  {
    "revision": "52d12db4dcb8deca59a0",
    "url": "/static/js/43.9e976870.chunk.js"
  },
  {
    "revision": "1112dbed09f13a0fb501",
    "url": "/static/js/44.bb884f66.chunk.js"
  },
  {
    "revision": "a38d0cb076016865c2f8",
    "url": "/static/js/45.ec2cce6b.chunk.js"
  },
  {
    "revision": "34c903a4ecec8f625939",
    "url": "/static/js/46.29f8f8d5.chunk.js"
  },
  {
    "revision": "7368ef814f06b528f5c5",
    "url": "/static/js/47.d6ffe7bb.chunk.js"
  },
  {
    "revision": "3d7059f9ce114197d4d7",
    "url": "/static/js/48.80088a64.chunk.js"
  },
  {
    "revision": "7b363be682824df686a6",
    "url": "/static/js/49.c3d030f3.chunk.js"
  },
  {
    "revision": "0ca07cc9fba8b275597e",
    "url": "/static/js/5.12ab2302.chunk.js"
  },
  {
    "revision": "38c222f93fb705cfbc60",
    "url": "/static/js/50.8ed12421.chunk.js"
  },
  {
    "revision": "681c776e11996ff8dfcb",
    "url": "/static/js/51.bb4209a8.chunk.js"
  },
  {
    "revision": "057588688a8d52b51a68",
    "url": "/static/js/52.04ade200.chunk.js"
  },
  {
    "revision": "1ad25242b22b3a32ab6d",
    "url": "/static/js/53.ab1e6ad2.chunk.js"
  },
  {
    "revision": "a15a59957a51e9840adc",
    "url": "/static/js/54.4a93616c.chunk.js"
  },
  {
    "revision": "0166ed7ee97ecc41cc6c",
    "url": "/static/js/55.418eb5ca.chunk.js"
  },
  {
    "revision": "02b827d3337034d438e2",
    "url": "/static/js/56.7db6f728.chunk.js"
  },
  {
    "revision": "39093d88b44fbc18b1ff",
    "url": "/static/js/57.ffe94c8a.chunk.js"
  },
  {
    "revision": "0572cdd1673a39fc603d",
    "url": "/static/js/58.b137ab91.chunk.js"
  },
  {
    "revision": "399691147be09162d84a",
    "url": "/static/js/59.2a1ef024.chunk.js"
  },
  {
    "revision": "02e6622ae96699842bd3",
    "url": "/static/js/6.81b4f40c.chunk.js"
  },
  {
    "revision": "c1075cf0da9864ed393a",
    "url": "/static/js/60.b2983f2e.chunk.js"
  },
  {
    "revision": "6ccbb402b381b1c6075b",
    "url": "/static/js/61.1c0303db.chunk.js"
  },
  {
    "revision": "6d81f435c1557c1645ab",
    "url": "/static/js/62.0b33ffbc.chunk.js"
  },
  {
    "revision": "2d9e1b63dd97956332f6",
    "url": "/static/js/63.8c181489.chunk.js"
  },
  {
    "revision": "30788bb8a6d1d6ab2cdc",
    "url": "/static/js/64.b495d27f.chunk.js"
  },
  {
    "revision": "b22b533e325d332a2fac",
    "url": "/static/js/65.48fee6c4.chunk.js"
  },
  {
    "revision": "fe05f3b04bebc54f880c",
    "url": "/static/js/66.b2b0d543.chunk.js"
  },
  {
    "revision": "719aacfa9272674d47be",
    "url": "/static/js/67.586635bb.chunk.js"
  },
  {
    "revision": "a2ade62889e7d8c2913b",
    "url": "/static/js/68.88d0a4e4.chunk.js"
  },
  {
    "revision": "970ebad9c91b45d519e5",
    "url": "/static/js/69.5334bd6f.chunk.js"
  },
  {
    "revision": "e97dda8591122c0f08ae",
    "url": "/static/js/7.0c67285c.chunk.js"
  },
  {
    "revision": "7dbe019078f602e51db8",
    "url": "/static/js/70.3de258b5.chunk.js"
  },
  {
    "revision": "a99bf222f95ad7c222b0",
    "url": "/static/js/71.ce183908.chunk.js"
  },
  {
    "revision": "fee1a718ba51f1ae4168",
    "url": "/static/js/72.284d1a0c.chunk.js"
  },
  {
    "revision": "666dc98fc588785c28b3",
    "url": "/static/js/73.da4d8388.chunk.js"
  },
  {
    "revision": "f428d4ff7a1f05eb545d",
    "url": "/static/js/74.73fd2057.chunk.js"
  },
  {
    "revision": "d9afa03d107bf4965fce",
    "url": "/static/js/75.3a84e76d.chunk.js"
  },
  {
    "revision": "042078316a2caeafcb19",
    "url": "/static/js/76.30cb67cd.chunk.js"
  },
  {
    "revision": "7af38e0aa20a2a7d39dd",
    "url": "/static/js/77.c6e11d58.chunk.js"
  },
  {
    "revision": "1315f2c373f42102ee0d",
    "url": "/static/js/8.690b51a5.chunk.js"
  },
  {
    "revision": "0121c2bdfc09a5d9d132",
    "url": "/static/js/9.e04ea5cc.chunk.js"
  },
  {
    "revision": "263abd1488e213a5605d",
    "url": "/static/js/main.1db442c2.chunk.js"
  },
  {
    "revision": "0a0a968b1a647cb20a89",
    "url": "/static/js/runtime-main.79d056fd.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);