self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2014d19a98b7d20252d3347e27bdf9fe",
    "url": "/index.html"
  },
  {
    "revision": "c87b145cb9930f6f4d52",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "485038a452f79ff6814c",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "1fcc6678d749226e74ba",
    "url": "/static/css/14.e5bec8e7.chunk.css"
  },
  {
    "revision": "33744562404f6fda1fb4",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "6dc4f6f436e72a868bbb",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "c87b145cb9930f6f4d52",
    "url": "/static/js/0.7e617cbc.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.7e617cbc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d47f93706154e47466b7",
    "url": "/static/js/1.86a279f9.chunk.js"
  },
  {
    "revision": "b0af1fae910756c344e0",
    "url": "/static/js/10.3b50d5f8.chunk.js"
  },
  {
    "revision": "485038a452f79ff6814c",
    "url": "/static/js/13.01560b02.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.01560b02.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1fcc6678d749226e74ba",
    "url": "/static/js/14.1edd8da4.chunk.js"
  },
  {
    "revision": "33744562404f6fda1fb4",
    "url": "/static/js/15.10bb73a8.chunk.js"
  },
  {
    "revision": "23973e24d491ee6750ea",
    "url": "/static/js/16.41ff0222.chunk.js"
  },
  {
    "revision": "d5c98f2ad05b2503a032",
    "url": "/static/js/17.5d4cc52f.chunk.js"
  },
  {
    "revision": "cb48c1e31a34a126f131",
    "url": "/static/js/18.134ac4be.chunk.js"
  },
  {
    "revision": "4617b6e7a4a9c549edca",
    "url": "/static/js/19.3d0dc519.chunk.js"
  },
  {
    "revision": "16d2e603542d487e7236",
    "url": "/static/js/2.b814b31a.chunk.js"
  },
  {
    "revision": "1a6bc3e6bd2d809c5e59",
    "url": "/static/js/20.bb2ce668.chunk.js"
  },
  {
    "revision": "c8c1d30f0a620af4c30d",
    "url": "/static/js/21.f81f1138.chunk.js"
  },
  {
    "revision": "69163f96c4787c31fcaa",
    "url": "/static/js/22.6822716d.chunk.js"
  },
  {
    "revision": "7ed346a54abbf04f98e0",
    "url": "/static/js/23.d2196f1a.chunk.js"
  },
  {
    "revision": "834e1510cbff05c9e69c",
    "url": "/static/js/24.7929e7da.chunk.js"
  },
  {
    "revision": "68723993065227a1e454",
    "url": "/static/js/25.6584f6a7.chunk.js"
  },
  {
    "revision": "610621c5373a2aa8b717",
    "url": "/static/js/26.dd0f1742.chunk.js"
  },
  {
    "revision": "9dfee1b1f23876556ade",
    "url": "/static/js/27.333dcf8b.chunk.js"
  },
  {
    "revision": "5bddb8484d1c1f0fb367",
    "url": "/static/js/28.5e7e6332.chunk.js"
  },
  {
    "revision": "b42fd03c262e9bfde389",
    "url": "/static/js/29.9146bc44.chunk.js"
  },
  {
    "revision": "b04538596ae804f414e9",
    "url": "/static/js/3.3755cc1e.chunk.js"
  },
  {
    "revision": "cf2ad2485ac2f47f584a",
    "url": "/static/js/30.7bf5620a.chunk.js"
  },
  {
    "revision": "7e84a042b2773f9657d2",
    "url": "/static/js/31.f150a384.chunk.js"
  },
  {
    "revision": "6d476db23e7546474b4e",
    "url": "/static/js/32.a808a693.chunk.js"
  },
  {
    "revision": "e17b945146af878ff977",
    "url": "/static/js/33.65ce17fd.chunk.js"
  },
  {
    "revision": "3ba9f6482bbb2045d681",
    "url": "/static/js/34.1fbd7ee7.chunk.js"
  },
  {
    "revision": "8c4e066a4969990a1048",
    "url": "/static/js/35.8b8f65ab.chunk.js"
  },
  {
    "revision": "c489c39b409bf1c065a6",
    "url": "/static/js/36.01a6f0f5.chunk.js"
  },
  {
    "revision": "8202f3dbf7846e46ee5f",
    "url": "/static/js/37.578755f9.chunk.js"
  },
  {
    "revision": "d54870eefb025da9fd20",
    "url": "/static/js/38.f3cda7ae.chunk.js"
  },
  {
    "revision": "757ca41ca1071d38c87f",
    "url": "/static/js/39.7b9f6570.chunk.js"
  },
  {
    "revision": "e614cfea4a16b5c9efc0",
    "url": "/static/js/4.f076bfef.chunk.js"
  },
  {
    "revision": "9122a9eefdb3e88db1c6",
    "url": "/static/js/40.7cffdbe5.chunk.js"
  },
  {
    "revision": "024556b223b41b8dce11",
    "url": "/static/js/41.b7116e28.chunk.js"
  },
  {
    "revision": "75de236ceb46dd1da712",
    "url": "/static/js/42.72ca8ce5.chunk.js"
  },
  {
    "revision": "3c9afed8b6a9ed97ea84",
    "url": "/static/js/43.8ab1fd6c.chunk.js"
  },
  {
    "revision": "04b640cda85e6adbeee6",
    "url": "/static/js/44.66c31b20.chunk.js"
  },
  {
    "revision": "d6164929c556dc8822ae",
    "url": "/static/js/45.7a8db2d6.chunk.js"
  },
  {
    "revision": "227007747d308e68d64a",
    "url": "/static/js/46.00cffba9.chunk.js"
  },
  {
    "revision": "f53f20e00f51efa29b40",
    "url": "/static/js/47.861f3c8f.chunk.js"
  },
  {
    "revision": "2067d161c9c22e546949",
    "url": "/static/js/48.80524469.chunk.js"
  },
  {
    "revision": "a9dc785d32bbe90707d9",
    "url": "/static/js/49.384ff1b3.chunk.js"
  },
  {
    "revision": "3e323ada429c75f58005",
    "url": "/static/js/5.950e3a76.chunk.js"
  },
  {
    "revision": "2400f66035b15b772da7",
    "url": "/static/js/50.8c243279.chunk.js"
  },
  {
    "revision": "07986c7b9c28f793f91c",
    "url": "/static/js/51.c4a5a7f0.chunk.js"
  },
  {
    "revision": "0108678da0e00aff1fb4",
    "url": "/static/js/52.7bbf7583.chunk.js"
  },
  {
    "revision": "88db291684b1bd265290",
    "url": "/static/js/53.56dafb31.chunk.js"
  },
  {
    "revision": "0014973b0aa02bdb82a7",
    "url": "/static/js/54.ce111815.chunk.js"
  },
  {
    "revision": "d4f165efbb653a30783c",
    "url": "/static/js/55.aeb2a68a.chunk.js"
  },
  {
    "revision": "57a43e57f9265888ab4e",
    "url": "/static/js/56.161dc2e0.chunk.js"
  },
  {
    "revision": "9799e2e352f1cba0034a",
    "url": "/static/js/57.2a696dfb.chunk.js"
  },
  {
    "revision": "896033058edce0a87772",
    "url": "/static/js/58.86908f58.chunk.js"
  },
  {
    "revision": "a893ffa8b84f38c04bdd",
    "url": "/static/js/59.5f754c7a.chunk.js"
  },
  {
    "revision": "0f4cbc7a79c8c3542a35",
    "url": "/static/js/6.06251ae8.chunk.js"
  },
  {
    "revision": "6430b1121e8df10799ef",
    "url": "/static/js/60.49b7df6a.chunk.js"
  },
  {
    "revision": "02e712296601f5e472a9",
    "url": "/static/js/61.74d454ad.chunk.js"
  },
  {
    "revision": "e76d8d69517191353d00",
    "url": "/static/js/62.6a14eb6e.chunk.js"
  },
  {
    "revision": "84d8393c203884f396c7",
    "url": "/static/js/63.605fc0c9.chunk.js"
  },
  {
    "revision": "c119a54449b98ad4f4e8",
    "url": "/static/js/64.cced500d.chunk.js"
  },
  {
    "revision": "c3694ac12814bf21c904",
    "url": "/static/js/65.9be7bfbe.chunk.js"
  },
  {
    "revision": "e2ee67e5949599601645",
    "url": "/static/js/66.e948a116.chunk.js"
  },
  {
    "revision": "3fdb25d7ed36f1aec43f",
    "url": "/static/js/67.07e54a9a.chunk.js"
  },
  {
    "revision": "8d63d40e7779d1e2c718",
    "url": "/static/js/68.2f85268d.chunk.js"
  },
  {
    "revision": "bdbda3dcfd623d666d5f",
    "url": "/static/js/69.a1c1fe1b.chunk.js"
  },
  {
    "revision": "08b1a53acbc1182cfa43",
    "url": "/static/js/7.50c512f3.chunk.js"
  },
  {
    "revision": "d97cd9a7f25c57139abf",
    "url": "/static/js/70.fd959905.chunk.js"
  },
  {
    "revision": "6dea4e2dbe8cadb913e8",
    "url": "/static/js/71.bd3c7e1f.chunk.js"
  },
  {
    "revision": "dbfaab39c4406a69ef77",
    "url": "/static/js/72.a68957f6.chunk.js"
  },
  {
    "revision": "b84c0442d55a456a7b4d",
    "url": "/static/js/73.f393a747.chunk.js"
  },
  {
    "revision": "ad814022310d037d174a",
    "url": "/static/js/74.2b3577d2.chunk.js"
  },
  {
    "revision": "4e57a6851465bc0dba14",
    "url": "/static/js/75.478dcd95.chunk.js"
  },
  {
    "revision": "97d97c43231f60d2ca32",
    "url": "/static/js/76.d2a04791.chunk.js"
  },
  {
    "revision": "1db3e94212a5d6a98bbf",
    "url": "/static/js/77.e1c5d29e.chunk.js"
  },
  {
    "revision": "93d29ced188393afb573",
    "url": "/static/js/78.99bc3d24.chunk.js"
  },
  {
    "revision": "3614cd2276fc7e7f3bd5",
    "url": "/static/js/8.e23be4cb.chunk.js"
  },
  {
    "revision": "62649d102337239ab6b7",
    "url": "/static/js/9.b00a47bb.chunk.js"
  },
  {
    "revision": "6dc4f6f436e72a868bbb",
    "url": "/static/js/main.8dddb784.chunk.js"
  },
  {
    "revision": "4dc717dbe616201455b4",
    "url": "/static/js/runtime-main.d301019c.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);