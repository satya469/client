self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "66a36a5dca6947aae7755fd79baed708",
    "url": "/index.html"
  },
  {
    "revision": "99d5faa62e7ca90f71d9",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "13615ead2fc0ff45c98b",
    "url": "/static/css/14.dd0dd03e.chunk.css"
  },
  {
    "revision": "9ba19cadb99950c3d30f",
    "url": "/static/css/16.9d79d512.chunk.css"
  },
  {
    "revision": "4a5db317bdc7b736e331",
    "url": "/static/css/17.834d426e.chunk.css"
  },
  {
    "revision": "044766ea5b1868285420",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "99d5faa62e7ca90f71d9",
    "url": "/static/js/0.a949e8a8.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.a949e8a8.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8a4245b601d166ca6dc1",
    "url": "/static/js/1.3b617581.chunk.js"
  },
  {
    "revision": "a33882421a0f6e1d65e3",
    "url": "/static/js/10.0904154a.chunk.js"
  },
  {
    "revision": "463e10f1305d357896bb",
    "url": "/static/js/13.8ef79688.chunk.js"
  },
  {
    "revision": "f1b0fc3bcbbb783ff6804aa8082adddf",
    "url": "/static/js/13.8ef79688.chunk.js.LICENSE.txt"
  },
  {
    "revision": "13615ead2fc0ff45c98b",
    "url": "/static/js/14.85ad1e9c.chunk.js"
  },
  {
    "revision": "c2c3d35564ab7b6bcba05d8a33a64f93",
    "url": "/static/js/14.85ad1e9c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ee50550e95e9a4b08a63",
    "url": "/static/js/15.3b53c5da.chunk.js"
  },
  {
    "revision": "9ba19cadb99950c3d30f",
    "url": "/static/js/16.1f95cc3d.chunk.js"
  },
  {
    "revision": "4a5db317bdc7b736e331",
    "url": "/static/js/17.788e26ff.chunk.js"
  },
  {
    "revision": "9082a92ea61353f617c9",
    "url": "/static/js/18.b430afbe.chunk.js"
  },
  {
    "revision": "4ad547ec1b55d942ae5c",
    "url": "/static/js/19.f6097146.chunk.js"
  },
  {
    "revision": "b2739374d817c81733a5",
    "url": "/static/js/2.6a4676e1.chunk.js"
  },
  {
    "revision": "f31ce69248d64a869df7",
    "url": "/static/js/20.52552bf4.chunk.js"
  },
  {
    "revision": "3b77e23271d2b616981b",
    "url": "/static/js/21.1f9fbd2e.chunk.js"
  },
  {
    "revision": "43c0ba66bfa80a04e402",
    "url": "/static/js/22.60af9c2a.chunk.js"
  },
  {
    "revision": "3e600c364ada84be480b",
    "url": "/static/js/23.e258ad25.chunk.js"
  },
  {
    "revision": "2dc3a2b6a045172e2766",
    "url": "/static/js/24.dcb7f204.chunk.js"
  },
  {
    "revision": "1f7df99d46d2f4c1ca06",
    "url": "/static/js/25.5b81b8c9.chunk.js"
  },
  {
    "revision": "749e01d13af0e384f144",
    "url": "/static/js/26.61a6a41a.chunk.js"
  },
  {
    "revision": "8078185766d4b32fe1a2",
    "url": "/static/js/27.d53dfbd3.chunk.js"
  },
  {
    "revision": "6019b6102b45033f40a0",
    "url": "/static/js/28.f043f67a.chunk.js"
  },
  {
    "revision": "e6b5e81a29575ae37f71",
    "url": "/static/js/29.0824c239.chunk.js"
  },
  {
    "revision": "363367ac4dea63ed54d2",
    "url": "/static/js/3.bbd6110c.chunk.js"
  },
  {
    "revision": "ca89238bfd944cb2f260",
    "url": "/static/js/30.c3510277.chunk.js"
  },
  {
    "revision": "e5b3e223877b5a7a4c48",
    "url": "/static/js/31.24b920ca.chunk.js"
  },
  {
    "revision": "c94c7796fc9068362a78",
    "url": "/static/js/32.558d77d5.chunk.js"
  },
  {
    "revision": "4c6f0a2c7cbedcfe2673",
    "url": "/static/js/33.b5404821.chunk.js"
  },
  {
    "revision": "08e20dc7902ffa97d895",
    "url": "/static/js/34.1145d068.chunk.js"
  },
  {
    "revision": "68f1ce650d69dc80c7a5",
    "url": "/static/js/35.6ab6f3d9.chunk.js"
  },
  {
    "revision": "9c77d0570b00e36b196b",
    "url": "/static/js/36.bf972b07.chunk.js"
  },
  {
    "revision": "4ce30945fedced391387",
    "url": "/static/js/37.61e1a6be.chunk.js"
  },
  {
    "revision": "0dcc2e5d904f21379601",
    "url": "/static/js/38.a55f01e2.chunk.js"
  },
  {
    "revision": "62fc721c03194d2442ab",
    "url": "/static/js/39.c4141ee4.chunk.js"
  },
  {
    "revision": "ebf200fdead9b8f6a7c9",
    "url": "/static/js/4.53b12746.chunk.js"
  },
  {
    "revision": "c5fdc0d7a9b4e77b3e8f",
    "url": "/static/js/40.9f0a5372.chunk.js"
  },
  {
    "revision": "362c3dd638696fda9606",
    "url": "/static/js/41.8e59833d.chunk.js"
  },
  {
    "revision": "0de545278a06027b885d",
    "url": "/static/js/42.dc9079e2.chunk.js"
  },
  {
    "revision": "2253a69a4bfdb0450fac",
    "url": "/static/js/43.3f75756d.chunk.js"
  },
  {
    "revision": "ae9c602755aa7b1cf323",
    "url": "/static/js/44.3423591a.chunk.js"
  },
  {
    "revision": "c0b0278516c1f7f8626e",
    "url": "/static/js/45.e2f756b8.chunk.js"
  },
  {
    "revision": "826cb90bbb7d9f16f5d8",
    "url": "/static/js/46.766a1052.chunk.js"
  },
  {
    "revision": "d3226b05754f2bbd7ebc",
    "url": "/static/js/47.b3182fec.chunk.js"
  },
  {
    "revision": "2207f90d5eac165bad82",
    "url": "/static/js/48.6fb7dd92.chunk.js"
  },
  {
    "revision": "1b04814155c3288e4fbf",
    "url": "/static/js/49.99bc6f36.chunk.js"
  },
  {
    "revision": "320a11e026f151bea5d1",
    "url": "/static/js/5.ad96d284.chunk.js"
  },
  {
    "revision": "8ec02d7fea78ce7c332d",
    "url": "/static/js/50.01e8e218.chunk.js"
  },
  {
    "revision": "1a7481b3f8c262ab68e2",
    "url": "/static/js/51.d4cb5ddd.chunk.js"
  },
  {
    "revision": "033a1f63f584bb4225b5",
    "url": "/static/js/52.840f8e20.chunk.js"
  },
  {
    "revision": "b1ff6c9e101020603bd5",
    "url": "/static/js/53.d7119672.chunk.js"
  },
  {
    "revision": "20d679736c9607a10248",
    "url": "/static/js/54.72806ac5.chunk.js"
  },
  {
    "revision": "fc3c449767ff72258bb7",
    "url": "/static/js/55.dd9eba08.chunk.js"
  },
  {
    "revision": "20e91a316e9c63ceadbb",
    "url": "/static/js/56.35f5ad74.chunk.js"
  },
  {
    "revision": "e24b138abd5333c063cd",
    "url": "/static/js/57.793b7a66.chunk.js"
  },
  {
    "revision": "2df69b2dea543cdae62c",
    "url": "/static/js/58.b3f026e6.chunk.js"
  },
  {
    "revision": "6ea306b7f41d12ab78f5",
    "url": "/static/js/59.4495a351.chunk.js"
  },
  {
    "revision": "0c5a80d615d9c321b007",
    "url": "/static/js/6.a6548e4f.chunk.js"
  },
  {
    "revision": "10acf7862cb4afbd7699",
    "url": "/static/js/60.6d6dfdb1.chunk.js"
  },
  {
    "revision": "cd8b999878cae56aa62f",
    "url": "/static/js/61.3b4cf850.chunk.js"
  },
  {
    "revision": "211270b962a14996a7fb",
    "url": "/static/js/62.2d98d6c8.chunk.js"
  },
  {
    "revision": "51840c27351bbea849ca",
    "url": "/static/js/63.a9ac5667.chunk.js"
  },
  {
    "revision": "89198ee7aca59d5318d8",
    "url": "/static/js/64.1f06fc03.chunk.js"
  },
  {
    "revision": "7400bf3aae8c290b697d",
    "url": "/static/js/65.6054a049.chunk.js"
  },
  {
    "revision": "79033c69bef0ef3b2000",
    "url": "/static/js/66.c6e5e1db.chunk.js"
  },
  {
    "revision": "bc6d7c651ede4b1c69c9",
    "url": "/static/js/67.43e9b3dd.chunk.js"
  },
  {
    "revision": "4c0bf57e67d99f70e47b",
    "url": "/static/js/68.3bb68be8.chunk.js"
  },
  {
    "revision": "5ecaf5a7bd34b5a56d25",
    "url": "/static/js/69.c31019bc.chunk.js"
  },
  {
    "revision": "14ec68605ddc304cc6c0",
    "url": "/static/js/7.6ff7901f.chunk.js"
  },
  {
    "revision": "4c2dfef7748365f10a89",
    "url": "/static/js/70.b352df9c.chunk.js"
  },
  {
    "revision": "f03e7c583eff7c963474",
    "url": "/static/js/71.fe4ba461.chunk.js"
  },
  {
    "revision": "91f3f89b9768b920af91",
    "url": "/static/js/72.8c9ce082.chunk.js"
  },
  {
    "revision": "428fba864c3ad8f4f6b2",
    "url": "/static/js/73.d53c8a7e.chunk.js"
  },
  {
    "revision": "7b348a3bf67c12266fd8",
    "url": "/static/js/74.095a70f8.chunk.js"
  },
  {
    "revision": "b06813ded5ec77424755",
    "url": "/static/js/75.d84afa7d.chunk.js"
  },
  {
    "revision": "726fe4170860eed972a5",
    "url": "/static/js/76.8d0dea60.chunk.js"
  },
  {
    "revision": "03631d53d49d4252a7a4",
    "url": "/static/js/77.486ac9ea.chunk.js"
  },
  {
    "revision": "e29f171ea2259905df58",
    "url": "/static/js/78.464b81e6.chunk.js"
  },
  {
    "revision": "a587edaa63068e5399e2",
    "url": "/static/js/79.ee08717e.chunk.js"
  },
  {
    "revision": "1973468b54ea418f1b61",
    "url": "/static/js/8.e5feece6.chunk.js"
  },
  {
    "revision": "b485c9acbcf50e7e9a8b",
    "url": "/static/js/80.876cab8e.chunk.js"
  },
  {
    "revision": "bfd339e675311bc33914",
    "url": "/static/js/81.f5bac85b.chunk.js"
  },
  {
    "revision": "f7c2973ffeee2ecb5519",
    "url": "/static/js/82.fad57f8e.chunk.js"
  },
  {
    "revision": "bc23ddfdf82ac9997f1d",
    "url": "/static/js/83.1136fac1.chunk.js"
  },
  {
    "revision": "b783b25b7db559d04d17",
    "url": "/static/js/9.03f22375.chunk.js"
  },
  {
    "revision": "044766ea5b1868285420",
    "url": "/static/js/main.33cc1046.chunk.js"
  },
  {
    "revision": "665d4ea414ebe97ffa3b",
    "url": "/static/js/runtime-main.a154b6b0.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);