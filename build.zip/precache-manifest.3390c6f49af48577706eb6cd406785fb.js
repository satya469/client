self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b457752200182680e897e43855c71df4",
    "url": "/index.html"
  },
  {
    "revision": "075ecfb6d316c4f48a43",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "6747a1d653bac7a47b65",
    "url": "/static/css/11.2e947bf2.chunk.css"
  },
  {
    "revision": "14b6e5717ba5cad5e36e",
    "url": "/static/css/12.5ca8bf9f.chunk.css"
  },
  {
    "revision": "013808544117ea3b1a49",
    "url": "/static/css/13.ac09eb94.chunk.css"
  },
  {
    "revision": "c90afff1521cbe7aaf22",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "075ecfb6d316c4f48a43",
    "url": "/static/js/0.ace55a5d.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.ace55a5d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6af78c7b845b62948bf9",
    "url": "/static/js/1.8f39f9a3.chunk.js"
  },
  {
    "revision": "6747a1d653bac7a47b65",
    "url": "/static/js/11.3178c940.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/11.3178c940.chunk.js.LICENSE.txt"
  },
  {
    "revision": "14b6e5717ba5cad5e36e",
    "url": "/static/js/12.d0868f4f.chunk.js"
  },
  {
    "revision": "013808544117ea3b1a49",
    "url": "/static/js/13.166f3112.chunk.js"
  },
  {
    "revision": "352cb65021d37e8ddc1d",
    "url": "/static/js/14.e3b2c232.chunk.js"
  },
  {
    "revision": "15d809696d8895b2ffd8",
    "url": "/static/js/15.00b7dbf7.chunk.js"
  },
  {
    "revision": "80f87ff34e5a906c9cc3",
    "url": "/static/js/16.8de040d6.chunk.js"
  },
  {
    "revision": "280991728527d1c3bd89",
    "url": "/static/js/17.da8d7b64.chunk.js"
  },
  {
    "revision": "b8a2f88a2ce6113285dc",
    "url": "/static/js/18.557accdc.chunk.js"
  },
  {
    "revision": "fff99be5b6f6ec2df261",
    "url": "/static/js/19.463d3f8d.chunk.js"
  },
  {
    "revision": "42757fcd50e3ff640b46",
    "url": "/static/js/2.e4d53722.chunk.js"
  },
  {
    "revision": "7ee0ce4e363082d7098d",
    "url": "/static/js/20.027bd102.chunk.js"
  },
  {
    "revision": "db9950487587bc084807",
    "url": "/static/js/21.55e9524e.chunk.js"
  },
  {
    "revision": "d288c9bf8d54f71e10e4",
    "url": "/static/js/22.bbb634d0.chunk.js"
  },
  {
    "revision": "d2805f6ceb3e7862623b",
    "url": "/static/js/23.2649c4ca.chunk.js"
  },
  {
    "revision": "29d04328f75dc619adc7",
    "url": "/static/js/24.cc527c85.chunk.js"
  },
  {
    "revision": "55b87442259cb92191ea",
    "url": "/static/js/25.4e0498b7.chunk.js"
  },
  {
    "revision": "3fe3357f7ba686d1f571",
    "url": "/static/js/26.8d67fd73.chunk.js"
  },
  {
    "revision": "2e0211583bad660a22ac",
    "url": "/static/js/27.bd1de58d.chunk.js"
  },
  {
    "revision": "6e14183aba075499aab7",
    "url": "/static/js/28.39857ef7.chunk.js"
  },
  {
    "revision": "c821e33518a22a1e93ab",
    "url": "/static/js/29.c864c8d7.chunk.js"
  },
  {
    "revision": "66db26b63a10b2bb060f",
    "url": "/static/js/3.35b6d888.chunk.js"
  },
  {
    "revision": "7d479735ccdd2d88b34d",
    "url": "/static/js/30.0b8b22de.chunk.js"
  },
  {
    "revision": "5bcf5aa70f27e54e3226",
    "url": "/static/js/31.2da35242.chunk.js"
  },
  {
    "revision": "1fb509357dccb21a429c",
    "url": "/static/js/32.64dda8b0.chunk.js"
  },
  {
    "revision": "cf6b1c413525de9ec6ba",
    "url": "/static/js/33.fffeefe9.chunk.js"
  },
  {
    "revision": "b322b194d49f95b0d3d9",
    "url": "/static/js/34.3df22aaf.chunk.js"
  },
  {
    "revision": "cae7b37492cc7d473905",
    "url": "/static/js/35.76a1a766.chunk.js"
  },
  {
    "revision": "65cd49f618c206caad39",
    "url": "/static/js/36.95eac3d2.chunk.js"
  },
  {
    "revision": "4c8c7113a00616cbb6b0",
    "url": "/static/js/37.a94c5c46.chunk.js"
  },
  {
    "revision": "89181fe7e20d9282113b",
    "url": "/static/js/38.9a01654c.chunk.js"
  },
  {
    "revision": "babdf148231e6d7bdb51",
    "url": "/static/js/39.bfb71956.chunk.js"
  },
  {
    "revision": "d8632cd21362aa0d7e2b",
    "url": "/static/js/4.1c1a7f24.chunk.js"
  },
  {
    "revision": "996aadd983e2a607ef70",
    "url": "/static/js/40.479f4e07.chunk.js"
  },
  {
    "revision": "4ac88d3282993be66c78",
    "url": "/static/js/41.6817f6cb.chunk.js"
  },
  {
    "revision": "80504ecbdf2555dbd411",
    "url": "/static/js/42.85d2e491.chunk.js"
  },
  {
    "revision": "935fa0ae58432dd4f4fc",
    "url": "/static/js/43.ca9c7390.chunk.js"
  },
  {
    "revision": "f01bdcf61f2cf6eb60ac",
    "url": "/static/js/44.2340393c.chunk.js"
  },
  {
    "revision": "b370847dc5a61ccdddf5",
    "url": "/static/js/45.a8d9e5cc.chunk.js"
  },
  {
    "revision": "134362ed0f2e5644e007",
    "url": "/static/js/46.c605d94b.chunk.js"
  },
  {
    "revision": "39ac062ed636d85d7c7d",
    "url": "/static/js/47.c51735a7.chunk.js"
  },
  {
    "revision": "65e454b2c84eb92c867f",
    "url": "/static/js/48.6d610815.chunk.js"
  },
  {
    "revision": "051b74e665d303aed34d",
    "url": "/static/js/49.38c9a403.chunk.js"
  },
  {
    "revision": "8ef32f3574edd88b96de",
    "url": "/static/js/5.415ee878.chunk.js"
  },
  {
    "revision": "96fa2e10bbd1d9855264",
    "url": "/static/js/50.890ef6b4.chunk.js"
  },
  {
    "revision": "17488a71a2d8d4d676cc",
    "url": "/static/js/51.6651eb99.chunk.js"
  },
  {
    "revision": "e2b14bfe67cc7c1c6870",
    "url": "/static/js/52.1dfbe809.chunk.js"
  },
  {
    "revision": "974fcb031b41559b07bc",
    "url": "/static/js/53.fc8456e5.chunk.js"
  },
  {
    "revision": "b96a3fafbb88269e379c",
    "url": "/static/js/54.448fec99.chunk.js"
  },
  {
    "revision": "31ae74b4e77f46772309",
    "url": "/static/js/55.e9561550.chunk.js"
  },
  {
    "revision": "2f9c38257ad3c12baf18",
    "url": "/static/js/56.29b6b3ae.chunk.js"
  },
  {
    "revision": "e3046f877a1532e9b326",
    "url": "/static/js/57.9753708e.chunk.js"
  },
  {
    "revision": "eb7004d7d0c5995b6d67",
    "url": "/static/js/58.8276ceec.chunk.js"
  },
  {
    "revision": "bda83f0925fe02378baa",
    "url": "/static/js/59.f4beee90.chunk.js"
  },
  {
    "revision": "50a24bd7018e939c64f6",
    "url": "/static/js/6.d0896d63.chunk.js"
  },
  {
    "revision": "6c6b0e2081c47fb704e0",
    "url": "/static/js/60.a5b01a51.chunk.js"
  },
  {
    "revision": "42221c25dacc0d82e063",
    "url": "/static/js/61.6cb1df88.chunk.js"
  },
  {
    "revision": "4e8cb665106c95e41eee",
    "url": "/static/js/62.0107d3b3.chunk.js"
  },
  {
    "revision": "7356c3b4b266ead32881",
    "url": "/static/js/63.a89927c3.chunk.js"
  },
  {
    "revision": "6db0ea56cf592836e587",
    "url": "/static/js/64.fd998ed7.chunk.js"
  },
  {
    "revision": "c8ebbb2e29150c3f24da",
    "url": "/static/js/65.33f7f003.chunk.js"
  },
  {
    "revision": "3513127d0519e96e4406",
    "url": "/static/js/66.70b989e7.chunk.js"
  },
  {
    "revision": "0a30c504aa2141a8d003",
    "url": "/static/js/67.cfdcb023.chunk.js"
  },
  {
    "revision": "91281b526295437d2a21",
    "url": "/static/js/68.dd9f2995.chunk.js"
  },
  {
    "revision": "2e4b4df0f1bb346841d6",
    "url": "/static/js/69.d325e8e5.chunk.js"
  },
  {
    "revision": "78be9eda867916da2489",
    "url": "/static/js/7.db4ebabd.chunk.js"
  },
  {
    "revision": "89fab7bc525311616edf",
    "url": "/static/js/70.70e84496.chunk.js"
  },
  {
    "revision": "b5c9df41316acb090128",
    "url": "/static/js/71.d8f48a7e.chunk.js"
  },
  {
    "revision": "6c16346bbc4a0026c3f1",
    "url": "/static/js/72.445e5d0b.chunk.js"
  },
  {
    "revision": "73200f922967bcde5515",
    "url": "/static/js/73.970bd9cf.chunk.js"
  },
  {
    "revision": "db29d9f0e5240c028a28",
    "url": "/static/js/74.1ce37736.chunk.js"
  },
  {
    "revision": "e2baa319661a9b0c7399",
    "url": "/static/js/75.d2b3690b.chunk.js"
  },
  {
    "revision": "b24946297315de4d970e",
    "url": "/static/js/76.0f6af581.chunk.js"
  },
  {
    "revision": "70320f3523c4ff1b9d29",
    "url": "/static/js/8.a8f112bf.chunk.js"
  },
  {
    "revision": "c90afff1521cbe7aaf22",
    "url": "/static/js/main.1abeda4c.chunk.js"
  },
  {
    "revision": "dd526296517deb361353",
    "url": "/static/js/runtime-main.d3394e3d.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);