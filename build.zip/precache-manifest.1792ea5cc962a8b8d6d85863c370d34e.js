self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "be96c8c686a89bd485bbb5d3ab7bc419",
    "url": "/index.html"
  },
  {
    "revision": "fc306d006478f8d04241",
    "url": "/static/css/10.834d426e.chunk.css"
  },
  {
    "revision": "2c146b469fa65df6a32d",
    "url": "/static/css/12.3e68da18.chunk.css"
  },
  {
    "revision": "b92ee60ad19626bac1fd",
    "url": "/static/css/7.2e947bf2.chunk.css"
  },
  {
    "revision": "90d23a6166cf8a765d4f",
    "url": "/static/css/9.9d3ee8f2.chunk.css"
  },
  {
    "revision": "97d9de30d3f1d850e526",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "ee955e5033c32227ddc2",
    "url": "/static/js/0.03cba725.chunk.js"
  },
  {
    "revision": "093d8e212e0672e15e03",
    "url": "/static/js/1.9afb97cf.chunk.js"
  },
  {
    "revision": "fc306d006478f8d04241",
    "url": "/static/js/10.4a84e8d5.chunk.js"
  },
  {
    "revision": "d21770a837a7b8becddd",
    "url": "/static/js/11.3312c1a5.chunk.js"
  },
  {
    "revision": "2c146b469fa65df6a32d",
    "url": "/static/js/12.7c0ceeee.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/12.7c0ceeee.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8ac0962367f266624467",
    "url": "/static/js/13.f3bb1970.chunk.js"
  },
  {
    "revision": "74f9f968daa73823a22a",
    "url": "/static/js/14.d4055255.chunk.js"
  },
  {
    "revision": "79021fcd2573ad65db0e",
    "url": "/static/js/15.ad220818.chunk.js"
  },
  {
    "revision": "db4141f6f37adc0f68c1",
    "url": "/static/js/16.ec2e0f4d.chunk.js"
  },
  {
    "revision": "e58e16c951d8039580ed",
    "url": "/static/js/17.9db9d669.chunk.js"
  },
  {
    "revision": "3cdb751ce2735aa3e552",
    "url": "/static/js/18.be63f1cc.chunk.js"
  },
  {
    "revision": "79c184c6fad9a6e4b561",
    "url": "/static/js/19.04b54dcc.chunk.js"
  },
  {
    "revision": "c0cd5c1f7be66bb9be45",
    "url": "/static/js/2.7516c305.chunk.js"
  },
  {
    "revision": "983db6c23eac724d00d2",
    "url": "/static/js/20.98b8f786.chunk.js"
  },
  {
    "revision": "525e8d360523b77e7c0a",
    "url": "/static/js/21.cfa239dd.chunk.js"
  },
  {
    "revision": "da74d3830abdd95552f5",
    "url": "/static/js/22.1cf9b470.chunk.js"
  },
  {
    "revision": "dab430dc6510231089d4",
    "url": "/static/js/23.308b2510.chunk.js"
  },
  {
    "revision": "b88897024de795bd2862",
    "url": "/static/js/24.c882cd82.chunk.js"
  },
  {
    "revision": "ce69a56f2ae2b4a03319",
    "url": "/static/js/25.bb56ef7c.chunk.js"
  },
  {
    "revision": "f7e418297ce66d03e17c",
    "url": "/static/js/26.ef2fde37.chunk.js"
  },
  {
    "revision": "5e91af2b80ce53451443",
    "url": "/static/js/27.6c9f13f0.chunk.js"
  },
  {
    "revision": "170b6e7772c35013425c",
    "url": "/static/js/28.40934374.chunk.js"
  },
  {
    "revision": "6e91fe1f3ae24086a22e",
    "url": "/static/js/29.de1bd105.chunk.js"
  },
  {
    "revision": "58a37475c3525d46ef57",
    "url": "/static/js/3.907ddb1e.chunk.js"
  },
  {
    "revision": "d7f7b1094c605cca9d70",
    "url": "/static/js/30.36971172.chunk.js"
  },
  {
    "revision": "35173f20056ba9b5e70c",
    "url": "/static/js/31.8b599fe9.chunk.js"
  },
  {
    "revision": "d99f01afab85c79315ae",
    "url": "/static/js/32.880dbcf2.chunk.js"
  },
  {
    "revision": "bbb6227ac659d4902366",
    "url": "/static/js/33.24a1720a.chunk.js"
  },
  {
    "revision": "c9b417828b8e3da98c81",
    "url": "/static/js/34.fa38e48a.chunk.js"
  },
  {
    "revision": "260a64f02f066b59130c",
    "url": "/static/js/35.0eb27633.chunk.js"
  },
  {
    "revision": "291f40aafda0313c16be",
    "url": "/static/js/36.20cf7217.chunk.js"
  },
  {
    "revision": "a4860925e3e94e43b21d",
    "url": "/static/js/37.0ce8e638.chunk.js"
  },
  {
    "revision": "2d94ee1e0775496cbc39",
    "url": "/static/js/38.7aacbb25.chunk.js"
  },
  {
    "revision": "5ede532f1bf07e412ff1",
    "url": "/static/js/39.1e5f1c2f.chunk.js"
  },
  {
    "revision": "6930341e1e3242a6cda7",
    "url": "/static/js/4.ae23aa31.chunk.js"
  },
  {
    "revision": "0cf15a212e62c0015d70",
    "url": "/static/js/40.76942d4b.chunk.js"
  },
  {
    "revision": "0033c7423fcf37fa1efd",
    "url": "/static/js/41.61d147d1.chunk.js"
  },
  {
    "revision": "f895e987530d5b9d7412",
    "url": "/static/js/42.d75b8b41.chunk.js"
  },
  {
    "revision": "0f7191ef00779ed46fbb",
    "url": "/static/js/43.0df62621.chunk.js"
  },
  {
    "revision": "0bee8bf1d7cd364b2363",
    "url": "/static/js/44.2025eeee.chunk.js"
  },
  {
    "revision": "ce47e9ff87fd3330647d",
    "url": "/static/js/45.ca2a2400.chunk.js"
  },
  {
    "revision": "a2010f2191f0ab44674e",
    "url": "/static/js/46.a78a3d48.chunk.js"
  },
  {
    "revision": "603656a3780bbe309d6f",
    "url": "/static/js/47.42f84a8f.chunk.js"
  },
  {
    "revision": "1416d24306711ffee4e9",
    "url": "/static/js/48.209b6b65.chunk.js"
  },
  {
    "revision": "dbf42b0f8626f1826796",
    "url": "/static/js/49.0b3e80e9.chunk.js"
  },
  {
    "revision": "b92ee60ad19626bac1fd",
    "url": "/static/js/7.11b377f7.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/7.11b377f7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2cd0cd60c6d5d862574c",
    "url": "/static/js/8.e9b4da2e.chunk.js"
  },
  {
    "revision": "90d23a6166cf8a765d4f",
    "url": "/static/js/9.e47e7033.chunk.js"
  },
  {
    "revision": "97d9de30d3f1d850e526",
    "url": "/static/js/main.03fb9c65.chunk.js"
  },
  {
    "revision": "4a92bb3b4b22c5141db6",
    "url": "/static/js/runtime-main.7d29120c.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);