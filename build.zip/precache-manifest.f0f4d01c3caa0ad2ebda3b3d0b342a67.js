self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "121dd8968f886e2dc95e24665010f9c2",
    "url": "/index.html"
  },
  {
    "revision": "7b28030052f3aab5b035",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "148a40b82691719cc69e",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "6ea17b061e343a9dbc55",
    "url": "/static/css/14.0b0054da.chunk.css"
  },
  {
    "revision": "9108e1f06a4caba36ab5",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "30ee4b7cfc08a4e1d34e",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "7b28030052f3aab5b035",
    "url": "/static/js/0.91c08a8e.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.91c08a8e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8f0d85cba7d427f5e18e",
    "url": "/static/js/1.251284d9.chunk.js"
  },
  {
    "revision": "f8bc2f1db7372da4b5a1",
    "url": "/static/js/10.999f90f2.chunk.js"
  },
  {
    "revision": "148a40b82691719cc69e",
    "url": "/static/js/13.d049b1b0.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.d049b1b0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6ea17b061e343a9dbc55",
    "url": "/static/js/14.36fa34bd.chunk.js"
  },
  {
    "revision": "9108e1f06a4caba36ab5",
    "url": "/static/js/15.de05bf44.chunk.js"
  },
  {
    "revision": "dd132a6f7e1d05983d86",
    "url": "/static/js/16.331c2be1.chunk.js"
  },
  {
    "revision": "463604522a888d8c2005",
    "url": "/static/js/17.d0fe6edd.chunk.js"
  },
  {
    "revision": "3d9d4380983a0d4fd4e5",
    "url": "/static/js/18.694fd6b0.chunk.js"
  },
  {
    "revision": "9f211f42f69529569056",
    "url": "/static/js/19.eac03b0f.chunk.js"
  },
  {
    "revision": "1f2a5c33f799f1288655",
    "url": "/static/js/2.751298db.chunk.js"
  },
  {
    "revision": "35ded96c1057e01dbb53",
    "url": "/static/js/20.bd79b591.chunk.js"
  },
  {
    "revision": "4302b7a291a73dd2c663",
    "url": "/static/js/21.6485a8c3.chunk.js"
  },
  {
    "revision": "d37c15e5c4c5ab56c50f",
    "url": "/static/js/22.4bbc5952.chunk.js"
  },
  {
    "revision": "c5c195f6dbbfc410890c",
    "url": "/static/js/23.d5ee8547.chunk.js"
  },
  {
    "revision": "b38504803a860cd43f1c",
    "url": "/static/js/24.d61ec4c6.chunk.js"
  },
  {
    "revision": "c01ee456bce7b06de3fa",
    "url": "/static/js/25.3248edb3.chunk.js"
  },
  {
    "revision": "d97348183ae50d45a1db",
    "url": "/static/js/26.9e447390.chunk.js"
  },
  {
    "revision": "4fee952a57b7a77b7d2e",
    "url": "/static/js/27.87429e03.chunk.js"
  },
  {
    "revision": "490bcbc181042a43a178",
    "url": "/static/js/28.be523042.chunk.js"
  },
  {
    "revision": "291465dc66a599e04089",
    "url": "/static/js/29.b3713d36.chunk.js"
  },
  {
    "revision": "3d9bc61a8580dd00abdc",
    "url": "/static/js/3.b4cfa75e.chunk.js"
  },
  {
    "revision": "c6cfb2fe0b7a8b02f0d5",
    "url": "/static/js/30.ea3df18d.chunk.js"
  },
  {
    "revision": "a4ca4f52805b2825a9c0",
    "url": "/static/js/31.2ce7f28e.chunk.js"
  },
  {
    "revision": "9d79d0cbcc05b8c6c30a",
    "url": "/static/js/32.10da561a.chunk.js"
  },
  {
    "revision": "0192c1f30382728eb865",
    "url": "/static/js/33.a3174524.chunk.js"
  },
  {
    "revision": "f7df3d308994d4c1ca69",
    "url": "/static/js/34.848a91c5.chunk.js"
  },
  {
    "revision": "65a6eff24fdc1a45f3e6",
    "url": "/static/js/35.9eb9f2fe.chunk.js"
  },
  {
    "revision": "f682dba64b691d13898d",
    "url": "/static/js/36.18f3a39c.chunk.js"
  },
  {
    "revision": "5ce4ffc50f903c6995de",
    "url": "/static/js/37.96cd74a3.chunk.js"
  },
  {
    "revision": "c0f781f6d35feec727d3",
    "url": "/static/js/38.8bc879fc.chunk.js"
  },
  {
    "revision": "50d4d9342caf6b44c336",
    "url": "/static/js/39.f3bf48ff.chunk.js"
  },
  {
    "revision": "9ac9d45dfb2eda117f4a",
    "url": "/static/js/4.ed3fc5b3.chunk.js"
  },
  {
    "revision": "8844c08c1d655267970e",
    "url": "/static/js/40.876e3e37.chunk.js"
  },
  {
    "revision": "b7153c8c60a24267d6d5",
    "url": "/static/js/41.33b6a353.chunk.js"
  },
  {
    "revision": "ca8ca0f0ddb6e12903fb",
    "url": "/static/js/42.fd5fa9cf.chunk.js"
  },
  {
    "revision": "61ff315c951011f1cb3a",
    "url": "/static/js/43.2ebfdaee.chunk.js"
  },
  {
    "revision": "9e8fb7ac0638c06bdcc3",
    "url": "/static/js/44.99b13cba.chunk.js"
  },
  {
    "revision": "3dcc57795fab8be9124f",
    "url": "/static/js/45.b1bda4b5.chunk.js"
  },
  {
    "revision": "06c4104e2bc9eaa268b6",
    "url": "/static/js/46.59235c65.chunk.js"
  },
  {
    "revision": "2ead84fbf5d4c79a8fd9",
    "url": "/static/js/47.5ec6beb7.chunk.js"
  },
  {
    "revision": "205a26c25911277ccdac",
    "url": "/static/js/48.17fa7861.chunk.js"
  },
  {
    "revision": "d378411beb5a1ec5490e",
    "url": "/static/js/49.08c656c8.chunk.js"
  },
  {
    "revision": "b1f148476a668c25e089",
    "url": "/static/js/5.51815f29.chunk.js"
  },
  {
    "revision": "c8df6124953e4108d8e5",
    "url": "/static/js/50.32ea8a2b.chunk.js"
  },
  {
    "revision": "5ebfe240103a15d43d66",
    "url": "/static/js/51.4bdf8c25.chunk.js"
  },
  {
    "revision": "53bd9941e151565da865",
    "url": "/static/js/52.5c83ed62.chunk.js"
  },
  {
    "revision": "4b93aa705da3a6856e3a",
    "url": "/static/js/53.1763b320.chunk.js"
  },
  {
    "revision": "d681e97edde508b23efe",
    "url": "/static/js/54.29869468.chunk.js"
  },
  {
    "revision": "43108793354873cd60d6",
    "url": "/static/js/55.55342b13.chunk.js"
  },
  {
    "revision": "345ec56cb157c94839d0",
    "url": "/static/js/56.6507ccd2.chunk.js"
  },
  {
    "revision": "2623d4a5aecd862d2a8e",
    "url": "/static/js/57.55450a49.chunk.js"
  },
  {
    "revision": "32e025e8ff741b604485",
    "url": "/static/js/58.82e0cc8e.chunk.js"
  },
  {
    "revision": "ff9594922c72a59508c1",
    "url": "/static/js/59.f0419441.chunk.js"
  },
  {
    "revision": "cf8ce333a2121280595b",
    "url": "/static/js/6.31f39b15.chunk.js"
  },
  {
    "revision": "bfaf4dc85b10e6c62ba4",
    "url": "/static/js/60.75b74a94.chunk.js"
  },
  {
    "revision": "c2413ecf191436f3b9c8",
    "url": "/static/js/61.a56962cc.chunk.js"
  },
  {
    "revision": "b02d20cd99796788bd5f",
    "url": "/static/js/62.8096beb8.chunk.js"
  },
  {
    "revision": "3cdf60ddae715e42c786",
    "url": "/static/js/63.662f6deb.chunk.js"
  },
  {
    "revision": "88c75c9d0a0ec695c155",
    "url": "/static/js/64.6c744be1.chunk.js"
  },
  {
    "revision": "7c85f417ca2649a7f818",
    "url": "/static/js/65.21c55b93.chunk.js"
  },
  {
    "revision": "6d89c67915187100c846",
    "url": "/static/js/66.65425ffe.chunk.js"
  },
  {
    "revision": "77ecb51f0381c6395c67",
    "url": "/static/js/67.70f7ce32.chunk.js"
  },
  {
    "revision": "168077838f512186421b",
    "url": "/static/js/68.01980f04.chunk.js"
  },
  {
    "revision": "471783f8b2dfe2ef21af",
    "url": "/static/js/69.2b9e6201.chunk.js"
  },
  {
    "revision": "4e5c10fcaabcf9aa12f4",
    "url": "/static/js/7.1900c32a.chunk.js"
  },
  {
    "revision": "e6c2a63373f50bfa0e3e",
    "url": "/static/js/70.e79ac240.chunk.js"
  },
  {
    "revision": "a7efba02f06bcf8fa48a",
    "url": "/static/js/71.0b731aca.chunk.js"
  },
  {
    "revision": "0d23aaa9841d0f849996",
    "url": "/static/js/72.500f6c60.chunk.js"
  },
  {
    "revision": "446bd8a628bca34e03e0",
    "url": "/static/js/73.d6d9ed30.chunk.js"
  },
  {
    "revision": "4d39949d32f7c0de80f3",
    "url": "/static/js/74.1c28d21b.chunk.js"
  },
  {
    "revision": "2aa7cfbdffcacb2b06b3",
    "url": "/static/js/75.9507d32e.chunk.js"
  },
  {
    "revision": "26aa23d715bde7984a83",
    "url": "/static/js/76.ee7a671f.chunk.js"
  },
  {
    "revision": "64b6779068933ffed61e",
    "url": "/static/js/77.03340a14.chunk.js"
  },
  {
    "revision": "8832f53836333f527237",
    "url": "/static/js/78.3dd6d93d.chunk.js"
  },
  {
    "revision": "4c26cfcf3fdf69165323",
    "url": "/static/js/79.55b6c973.chunk.js"
  },
  {
    "revision": "aa0b68805ff47605f8b3",
    "url": "/static/js/8.3ddf3183.chunk.js"
  },
  {
    "revision": "a1a3540f087175a0735e",
    "url": "/static/js/80.188496c3.chunk.js"
  },
  {
    "revision": "aa2a4606fabdcd737808",
    "url": "/static/js/9.fa53b588.chunk.js"
  },
  {
    "revision": "30ee4b7cfc08a4e1d34e",
    "url": "/static/js/main.3feed3f4.chunk.js"
  },
  {
    "revision": "e4c2c7f52e20ca72028d",
    "url": "/static/js/runtime-main.3c9ab002.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);