self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d37ed4277072b43952277653dae91721",
    "url": "/index.html"
  },
  {
    "revision": "08f495fe03093987e12a",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "1f11d146e896c658e576",
    "url": "/static/css/12.2e947bf2.chunk.css"
  },
  {
    "revision": "7d431a00722ce271ffd2",
    "url": "/static/css/14.db940404.chunk.css"
  },
  {
    "revision": "d1e1f9398b53bb4e080c",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "ebf911f684b511250453",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "08f495fe03093987e12a",
    "url": "/static/js/0.7d773798.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.7d773798.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0de9fa6447d51648ba42",
    "url": "/static/js/1.cb828f96.chunk.js"
  },
  {
    "revision": "1f11d146e896c658e576",
    "url": "/static/js/12.0a0e7bd7.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/12.0a0e7bd7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1f7d4cd0b4a044fa95bc",
    "url": "/static/js/13.27345281.chunk.js"
  },
  {
    "revision": "7d431a00722ce271ffd2",
    "url": "/static/js/14.40885425.chunk.js"
  },
  {
    "revision": "d1e1f9398b53bb4e080c",
    "url": "/static/js/15.eee12485.chunk.js"
  },
  {
    "revision": "db52cc67cd0844cb6906",
    "url": "/static/js/16.5c792457.chunk.js"
  },
  {
    "revision": "82c5f723bcf33775155d",
    "url": "/static/js/17.e3a8377a.chunk.js"
  },
  {
    "revision": "e1d4bdb0ace376750533",
    "url": "/static/js/18.2e08b467.chunk.js"
  },
  {
    "revision": "f3d2e9dc268f73c3a670",
    "url": "/static/js/19.45cd4a9c.chunk.js"
  },
  {
    "revision": "4489f296e050805180b3",
    "url": "/static/js/2.04c65c44.chunk.js"
  },
  {
    "revision": "2258f060cd73567d1e56",
    "url": "/static/js/20.56e2fbb2.chunk.js"
  },
  {
    "revision": "85d18b5614afe2e542a3",
    "url": "/static/js/21.f947597d.chunk.js"
  },
  {
    "revision": "8ca50643fd66c4f5ff55",
    "url": "/static/js/22.5462d8af.chunk.js"
  },
  {
    "revision": "a8feb2c4dbb59fe32829",
    "url": "/static/js/23.d34e4795.chunk.js"
  },
  {
    "revision": "c7b26e97e989f587fa38",
    "url": "/static/js/24.bb2cd855.chunk.js"
  },
  {
    "revision": "b54ebf29c8510267f9cd",
    "url": "/static/js/25.100029a6.chunk.js"
  },
  {
    "revision": "c2c912adf1fef63c7e74",
    "url": "/static/js/26.544b8b81.chunk.js"
  },
  {
    "revision": "7c6bcec8f90b63646868",
    "url": "/static/js/27.24c2c3a4.chunk.js"
  },
  {
    "revision": "d53c47e2b830b8a01e89",
    "url": "/static/js/28.1bc2076d.chunk.js"
  },
  {
    "revision": "ab93cc41632bb750a2cf",
    "url": "/static/js/29.40229beb.chunk.js"
  },
  {
    "revision": "2841a0d13b12d7e5c607",
    "url": "/static/js/3.b5304605.chunk.js"
  },
  {
    "revision": "53aed84d5c785414e378",
    "url": "/static/js/30.5699f89b.chunk.js"
  },
  {
    "revision": "411823f724bff5867ed9",
    "url": "/static/js/31.db27defc.chunk.js"
  },
  {
    "revision": "2c9b881e1e840cd2bfff",
    "url": "/static/js/32.ceb07a94.chunk.js"
  },
  {
    "revision": "7702fb0bb641a6517ded",
    "url": "/static/js/33.fdcc5da8.chunk.js"
  },
  {
    "revision": "4e030f6489d9eee18167",
    "url": "/static/js/34.01f59d64.chunk.js"
  },
  {
    "revision": "22fa364e400eaeae2fe9",
    "url": "/static/js/35.01510823.chunk.js"
  },
  {
    "revision": "bc016e919ce132ff1279",
    "url": "/static/js/36.55b418fa.chunk.js"
  },
  {
    "revision": "be9f36ccffc0f5b7e643",
    "url": "/static/js/37.65335c06.chunk.js"
  },
  {
    "revision": "95a695bce0ba402bd587",
    "url": "/static/js/38.6cfc2b27.chunk.js"
  },
  {
    "revision": "a15fb9cd84b08a9ede59",
    "url": "/static/js/39.b463b4b7.chunk.js"
  },
  {
    "revision": "47884b0485d5893a57db",
    "url": "/static/js/4.c2503032.chunk.js"
  },
  {
    "revision": "c7d8a4e6e3929410622e",
    "url": "/static/js/40.515b7f25.chunk.js"
  },
  {
    "revision": "2d2b5de67981e138346a",
    "url": "/static/js/41.0e5202ee.chunk.js"
  },
  {
    "revision": "be6a21780f0c61faf8ae",
    "url": "/static/js/42.e0a8b3a7.chunk.js"
  },
  {
    "revision": "4d101e5a2ebd266f6ac4",
    "url": "/static/js/43.d7e2f678.chunk.js"
  },
  {
    "revision": "05fa8cb37da29f4a637b",
    "url": "/static/js/44.54bda28d.chunk.js"
  },
  {
    "revision": "39e845a6cdc0bc4ee380",
    "url": "/static/js/45.e7cd78db.chunk.js"
  },
  {
    "revision": "0a5fa3918ed85dd8993e",
    "url": "/static/js/46.0dd84bb2.chunk.js"
  },
  {
    "revision": "6d9210868c1b67c6afc6",
    "url": "/static/js/47.f0dbc563.chunk.js"
  },
  {
    "revision": "57b92b04d47c8c51f4a7",
    "url": "/static/js/48.9c6e81e4.chunk.js"
  },
  {
    "revision": "e4d01146ff54e5a7f477",
    "url": "/static/js/49.8d4c2b6e.chunk.js"
  },
  {
    "revision": "5ca470ce1b6c82f075b4",
    "url": "/static/js/5.09ae0a8c.chunk.js"
  },
  {
    "revision": "9804da20793b53a430a0",
    "url": "/static/js/50.a015bef9.chunk.js"
  },
  {
    "revision": "ac29e43b0fa27b1ec491",
    "url": "/static/js/51.07e86dbb.chunk.js"
  },
  {
    "revision": "dff3e3934c2138ca1c11",
    "url": "/static/js/52.3e03e423.chunk.js"
  },
  {
    "revision": "34832f7adbb970ad7d96",
    "url": "/static/js/53.b1dc4cd0.chunk.js"
  },
  {
    "revision": "d28c7d794e3d2e645b0b",
    "url": "/static/js/54.0a3a1dc1.chunk.js"
  },
  {
    "revision": "7ca5b201168662e2d869",
    "url": "/static/js/55.7ae32309.chunk.js"
  },
  {
    "revision": "93d7588a0107c8bdece3",
    "url": "/static/js/56.b50aa396.chunk.js"
  },
  {
    "revision": "5308e606671b0bdaddd2",
    "url": "/static/js/57.17a05f94.chunk.js"
  },
  {
    "revision": "b9fba90265e1d857baff",
    "url": "/static/js/58.f5066c94.chunk.js"
  },
  {
    "revision": "77b3fcf07d49c4cd2003",
    "url": "/static/js/59.d76f30a8.chunk.js"
  },
  {
    "revision": "aba208f2978bed049857",
    "url": "/static/js/6.6b674eea.chunk.js"
  },
  {
    "revision": "12d3bfd2e5d0f7b49592",
    "url": "/static/js/60.cd578120.chunk.js"
  },
  {
    "revision": "d242d9b4913f22d1cf37",
    "url": "/static/js/61.2c1875e8.chunk.js"
  },
  {
    "revision": "ab253b2a4dd84c2aca83",
    "url": "/static/js/62.e40dc4d9.chunk.js"
  },
  {
    "revision": "603f62a20480ec35fb0c",
    "url": "/static/js/63.984f918b.chunk.js"
  },
  {
    "revision": "e55bb257f70794bea3b4",
    "url": "/static/js/64.37f48eb8.chunk.js"
  },
  {
    "revision": "2bcac2b855ed57d2271b",
    "url": "/static/js/65.c09488a3.chunk.js"
  },
  {
    "revision": "c909dff8ae872a6d8a25",
    "url": "/static/js/66.10479fc8.chunk.js"
  },
  {
    "revision": "b4cfed19f6b00edd836e",
    "url": "/static/js/67.8ed9ab4c.chunk.js"
  },
  {
    "revision": "beb1f9ba90c816eeda9a",
    "url": "/static/js/68.3539cfef.chunk.js"
  },
  {
    "revision": "7d56359824f1b9e97de4",
    "url": "/static/js/69.bdc855e9.chunk.js"
  },
  {
    "revision": "fb3a4952187185ee0a7e",
    "url": "/static/js/7.52ab4832.chunk.js"
  },
  {
    "revision": "cd03cbb3907e8b4b9ebe",
    "url": "/static/js/70.024c2536.chunk.js"
  },
  {
    "revision": "64906326267eff3d9805",
    "url": "/static/js/71.eaee3378.chunk.js"
  },
  {
    "revision": "96db9ab7e97464450949",
    "url": "/static/js/72.5fc6670b.chunk.js"
  },
  {
    "revision": "62c9bd06817afda84d99",
    "url": "/static/js/73.35323ebf.chunk.js"
  },
  {
    "revision": "f11b0800be5c9a9e301b",
    "url": "/static/js/74.1fa2e049.chunk.js"
  },
  {
    "revision": "c41a220887c02bc0a1df",
    "url": "/static/js/75.9094fcf0.chunk.js"
  },
  {
    "revision": "6c64852b3495b82db00c",
    "url": "/static/js/76.82bc34ad.chunk.js"
  },
  {
    "revision": "01fbd9eb30637b890dfc",
    "url": "/static/js/77.d63f8aef.chunk.js"
  },
  {
    "revision": "9e645410c24b864e42ce",
    "url": "/static/js/78.6bd8b4e4.chunk.js"
  },
  {
    "revision": "e29e4ddc30f5635b3ba5",
    "url": "/static/js/79.f0b537d1.chunk.js"
  },
  {
    "revision": "d59eae502ba6beb1ffd1",
    "url": "/static/js/8.494250f9.chunk.js"
  },
  {
    "revision": "c53689a6f47029f84bf1",
    "url": "/static/js/80.02959f75.chunk.js"
  },
  {
    "revision": "9005c47f234a753fb202",
    "url": "/static/js/9.4cae83bc.chunk.js"
  },
  {
    "revision": "ebf911f684b511250453",
    "url": "/static/js/main.1ca9f42c.chunk.js"
  },
  {
    "revision": "c4d969642764419d1a72",
    "url": "/static/js/runtime-main.c0fabc69.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);