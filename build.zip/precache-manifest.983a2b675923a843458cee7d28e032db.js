self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "934d6f739884f9eea7fc786aedb627a9",
    "url": "/index.html"
  },
  {
    "revision": "7385088e25bb5f128e8f",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "7211d86d2a273087faac",
    "url": "/static/css/12.2e947bf2.chunk.css"
  },
  {
    "revision": "12017bebbd742e296e82",
    "url": "/static/css/14.b2298c9d.chunk.css"
  },
  {
    "revision": "15d301460d4ff9ecc3ad",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "cb6d944b2732172c744b",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "7385088e25bb5f128e8f",
    "url": "/static/js/0.95bbe992.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.95bbe992.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8050eff1a5352a61d6b9",
    "url": "/static/js/1.190c8809.chunk.js"
  },
  {
    "revision": "7211d86d2a273087faac",
    "url": "/static/js/12.9d0d1815.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/12.9d0d1815.chunk.js.LICENSE.txt"
  },
  {
    "revision": "abdd4221ddfaad96cb6d",
    "url": "/static/js/13.92db5437.chunk.js"
  },
  {
    "revision": "12017bebbd742e296e82",
    "url": "/static/js/14.25fb1d8c.chunk.js"
  },
  {
    "revision": "15d301460d4ff9ecc3ad",
    "url": "/static/js/15.bb759557.chunk.js"
  },
  {
    "revision": "f875af52a1fe645292a2",
    "url": "/static/js/16.03f7be88.chunk.js"
  },
  {
    "revision": "c3f26855d4db32038953",
    "url": "/static/js/17.05553e43.chunk.js"
  },
  {
    "revision": "e943a0e3749ea020fa0f",
    "url": "/static/js/18.c636657f.chunk.js"
  },
  {
    "revision": "6b04cba2bab023183ccf",
    "url": "/static/js/19.73e3301c.chunk.js"
  },
  {
    "revision": "8db2f603a4df5a63a347",
    "url": "/static/js/2.611437d6.chunk.js"
  },
  {
    "revision": "6c396f015edcda29964a",
    "url": "/static/js/20.0166408c.chunk.js"
  },
  {
    "revision": "6ed1d1218905a0f7641c",
    "url": "/static/js/21.7a127165.chunk.js"
  },
  {
    "revision": "a7d7d0f8cb71653a5e75",
    "url": "/static/js/22.c2583b4b.chunk.js"
  },
  {
    "revision": "3db480992b6a3d860047",
    "url": "/static/js/23.2472470a.chunk.js"
  },
  {
    "revision": "3a21f58a459f604cf077",
    "url": "/static/js/24.e228d356.chunk.js"
  },
  {
    "revision": "d0a195e07f50cb2e1fb2",
    "url": "/static/js/25.6c412312.chunk.js"
  },
  {
    "revision": "40ac3aba1a55db3acc01",
    "url": "/static/js/26.6794d751.chunk.js"
  },
  {
    "revision": "6b064bcf9ad79c1d249a",
    "url": "/static/js/27.d9f09cfc.chunk.js"
  },
  {
    "revision": "e40cba29bcb5414889f4",
    "url": "/static/js/28.9f4b9fd8.chunk.js"
  },
  {
    "revision": "1634bb688f861bf90bfa",
    "url": "/static/js/29.dc9fc14b.chunk.js"
  },
  {
    "revision": "9a1c11146758e06f3fff",
    "url": "/static/js/3.4122446f.chunk.js"
  },
  {
    "revision": "45b96a52d98f27d3306a",
    "url": "/static/js/30.a1d767ef.chunk.js"
  },
  {
    "revision": "d11e70d758cd587c8cec",
    "url": "/static/js/31.d274e1e6.chunk.js"
  },
  {
    "revision": "1d431e0907216a1aabf8",
    "url": "/static/js/32.56773d48.chunk.js"
  },
  {
    "revision": "9a45c88b7cdaf5e6f239",
    "url": "/static/js/33.98a63876.chunk.js"
  },
  {
    "revision": "66f064da6abf4ad5befe",
    "url": "/static/js/34.a7ddef68.chunk.js"
  },
  {
    "revision": "d1a49cfdfec0474dc353",
    "url": "/static/js/35.36df5b83.chunk.js"
  },
  {
    "revision": "438a3dd348dae749b59d",
    "url": "/static/js/36.ab25abff.chunk.js"
  },
  {
    "revision": "d71f675235dc8f57d84d",
    "url": "/static/js/37.fb97b453.chunk.js"
  },
  {
    "revision": "2e1add85a0e6eb89b1de",
    "url": "/static/js/38.2b57c320.chunk.js"
  },
  {
    "revision": "9a3c433059237ebc9d96",
    "url": "/static/js/39.9e9380a3.chunk.js"
  },
  {
    "revision": "416e7b17f145ccc69f0d",
    "url": "/static/js/4.867e7fd7.chunk.js"
  },
  {
    "revision": "0a31b98a29869edb821a",
    "url": "/static/js/40.4767bf98.chunk.js"
  },
  {
    "revision": "9e55b1c5250f0fbad90b",
    "url": "/static/js/41.35bcf3a9.chunk.js"
  },
  {
    "revision": "1aba56dc7a7f00406847",
    "url": "/static/js/42.0164211a.chunk.js"
  },
  {
    "revision": "54b5f141739b805eef32",
    "url": "/static/js/43.93f834f1.chunk.js"
  },
  {
    "revision": "b848c29eef2e0fe7eb5c",
    "url": "/static/js/44.063e1245.chunk.js"
  },
  {
    "revision": "d238fdbe64ed21eb1fa8",
    "url": "/static/js/45.f77a0421.chunk.js"
  },
  {
    "revision": "aee87eb29f4c6be05293",
    "url": "/static/js/46.94f41a1a.chunk.js"
  },
  {
    "revision": "c74dd4f4cdcda765b8bf",
    "url": "/static/js/47.a65aaea3.chunk.js"
  },
  {
    "revision": "f16b512cca7701476c77",
    "url": "/static/js/48.d73056af.chunk.js"
  },
  {
    "revision": "f4386532c0b44a343d24",
    "url": "/static/js/49.22b94e24.chunk.js"
  },
  {
    "revision": "34d27fb9e22e108ef4c9",
    "url": "/static/js/5.f8c5a9ab.chunk.js"
  },
  {
    "revision": "7af32a49df6a610b9465",
    "url": "/static/js/50.e1f251c2.chunk.js"
  },
  {
    "revision": "2e201f57a944cb53c7fa",
    "url": "/static/js/51.081e008e.chunk.js"
  },
  {
    "revision": "0cd1a621529e4c83d929",
    "url": "/static/js/52.d45f9e4d.chunk.js"
  },
  {
    "revision": "48549d59cb645fbaf760",
    "url": "/static/js/53.7e8e37d6.chunk.js"
  },
  {
    "revision": "5f41fd1b2532a2ba3afe",
    "url": "/static/js/54.15f1868c.chunk.js"
  },
  {
    "revision": "3874eaed30ff4c3fec2b",
    "url": "/static/js/55.6b808ec8.chunk.js"
  },
  {
    "revision": "9d1617847e55ceaf8b57",
    "url": "/static/js/56.2f7ac7de.chunk.js"
  },
  {
    "revision": "a04d67b654cf49498661",
    "url": "/static/js/57.0df2b4a7.chunk.js"
  },
  {
    "revision": "7d83cffe3b9a430ba5b8",
    "url": "/static/js/58.e35c2cbb.chunk.js"
  },
  {
    "revision": "db5bbf5639e6a18d5580",
    "url": "/static/js/59.6beb8848.chunk.js"
  },
  {
    "revision": "7fdfdb3ddd4aa5fa247b",
    "url": "/static/js/6.d178fec2.chunk.js"
  },
  {
    "revision": "836ab8b3b37ef556db42",
    "url": "/static/js/60.a37518d5.chunk.js"
  },
  {
    "revision": "aff3dae74013e00e3130",
    "url": "/static/js/61.c0ac0948.chunk.js"
  },
  {
    "revision": "9ad984b07c3a68d5206e",
    "url": "/static/js/62.a2829ec0.chunk.js"
  },
  {
    "revision": "7f840c977197e4289b7e",
    "url": "/static/js/63.27b67788.chunk.js"
  },
  {
    "revision": "81976a6d81db61f1ada6",
    "url": "/static/js/64.6298600e.chunk.js"
  },
  {
    "revision": "d0cca99961608f000820",
    "url": "/static/js/65.957f41a2.chunk.js"
  },
  {
    "revision": "60c617e1003138282978",
    "url": "/static/js/66.9a2972fa.chunk.js"
  },
  {
    "revision": "318b1b944c6eda2a4084",
    "url": "/static/js/67.fb5c2879.chunk.js"
  },
  {
    "revision": "401d7f94d21e82dc57c9",
    "url": "/static/js/68.c58d2fc7.chunk.js"
  },
  {
    "revision": "8b7d36f03102ef74b558",
    "url": "/static/js/69.d9134ff7.chunk.js"
  },
  {
    "revision": "fe3eb594b3565193946b",
    "url": "/static/js/7.06b5a1c9.chunk.js"
  },
  {
    "revision": "f898e87f663dd820e752",
    "url": "/static/js/70.44b7f1ba.chunk.js"
  },
  {
    "revision": "e6d2a964d4ee26ced7be",
    "url": "/static/js/71.bb3baf7f.chunk.js"
  },
  {
    "revision": "e1eba46bfeedbfdfea78",
    "url": "/static/js/72.8dd1d00d.chunk.js"
  },
  {
    "revision": "553906ee5d19f9a35b8c",
    "url": "/static/js/73.37d6b144.chunk.js"
  },
  {
    "revision": "02671f5855edf7c121a8",
    "url": "/static/js/74.7e34187e.chunk.js"
  },
  {
    "revision": "66c68c6b82b33bbccca3",
    "url": "/static/js/75.7c6f0ff8.chunk.js"
  },
  {
    "revision": "6adc21752abb39b763b9",
    "url": "/static/js/76.a8c4f5f1.chunk.js"
  },
  {
    "revision": "958b720746177195bc00",
    "url": "/static/js/77.ab180d67.chunk.js"
  },
  {
    "revision": "0769e8138cec7bc438aa",
    "url": "/static/js/8.6c2dc436.chunk.js"
  },
  {
    "revision": "4acf17b21d910e50c76e",
    "url": "/static/js/9.e8940a5f.chunk.js"
  },
  {
    "revision": "cb6d944b2732172c744b",
    "url": "/static/js/main.979ac5f7.chunk.js"
  },
  {
    "revision": "3339bc3093e7dac9f5c1",
    "url": "/static/js/runtime-main.38743c1b.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);