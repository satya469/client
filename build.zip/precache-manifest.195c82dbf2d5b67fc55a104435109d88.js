self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "912ff826c424554c29d70a7cfe54adbf",
    "url": "/index.html"
  },
  {
    "revision": "b22d4a4c72be28c4a9d2",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "47306485183478096e2b",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "44bef8b112cf41d4eb26",
    "url": "/static/css/14.1f503c0c.chunk.css"
  },
  {
    "revision": "40566eb9eecd934432c6",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "ec3c3da7a7c6acb1c48d",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "b22d4a4c72be28c4a9d2",
    "url": "/static/js/0.14ba94d9.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.14ba94d9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "815b5bdd30dadb2d5737",
    "url": "/static/js/1.93eb7db3.chunk.js"
  },
  {
    "revision": "8e07631d85210d17fb85",
    "url": "/static/js/10.a27bf4eb.chunk.js"
  },
  {
    "revision": "47306485183478096e2b",
    "url": "/static/js/13.2c6e2883.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.2c6e2883.chunk.js.LICENSE.txt"
  },
  {
    "revision": "44bef8b112cf41d4eb26",
    "url": "/static/js/14.b2fc6fc6.chunk.js"
  },
  {
    "revision": "40566eb9eecd934432c6",
    "url": "/static/js/15.3e79814b.chunk.js"
  },
  {
    "revision": "9fd7556311cb24dac170",
    "url": "/static/js/16.01f5c935.chunk.js"
  },
  {
    "revision": "793e705bbca7abacd4b3",
    "url": "/static/js/17.20df1204.chunk.js"
  },
  {
    "revision": "b49e5d69dd245035f66c",
    "url": "/static/js/18.25fb9cef.chunk.js"
  },
  {
    "revision": "aaaa9bb02d75725d52b8",
    "url": "/static/js/19.8b42e139.chunk.js"
  },
  {
    "revision": "1f2a5c33f799f1288655",
    "url": "/static/js/2.751298db.chunk.js"
  },
  {
    "revision": "5848dccc0097f3218e7e",
    "url": "/static/js/20.a8e24cab.chunk.js"
  },
  {
    "revision": "ab7ff4a49f30595f3ef8",
    "url": "/static/js/21.47755db0.chunk.js"
  },
  {
    "revision": "aa3ba80f5fbea8283bb9",
    "url": "/static/js/22.3d366784.chunk.js"
  },
  {
    "revision": "601a89fe22ee9acbc9fa",
    "url": "/static/js/23.712f0f3d.chunk.js"
  },
  {
    "revision": "fbd00b56841e3ebf57a5",
    "url": "/static/js/24.cd7797ef.chunk.js"
  },
  {
    "revision": "ca0a1115527bd6d12194",
    "url": "/static/js/25.d2063b64.chunk.js"
  },
  {
    "revision": "d441229366b657d0f0a1",
    "url": "/static/js/26.eb746de0.chunk.js"
  },
  {
    "revision": "7c2370faeb43088b010c",
    "url": "/static/js/27.15880ae3.chunk.js"
  },
  {
    "revision": "30f4338cdbf23cd79bde",
    "url": "/static/js/28.9752ba29.chunk.js"
  },
  {
    "revision": "78aaa8a08b7a2562514c",
    "url": "/static/js/29.e1f0c1bf.chunk.js"
  },
  {
    "revision": "2f9f4c1cdcf268ebf61b",
    "url": "/static/js/3.4309ee85.chunk.js"
  },
  {
    "revision": "70679a3f72195728fe6e",
    "url": "/static/js/30.fcf28f1e.chunk.js"
  },
  {
    "revision": "7b539ec80e070ae23968",
    "url": "/static/js/31.96dea437.chunk.js"
  },
  {
    "revision": "f7bd019fa5a83d6d8245",
    "url": "/static/js/32.73b34012.chunk.js"
  },
  {
    "revision": "69e4ca8f324cfe82ff3e",
    "url": "/static/js/33.888a76a8.chunk.js"
  },
  {
    "revision": "7f0249b528b5058e9cbb",
    "url": "/static/js/34.9eab90d8.chunk.js"
  },
  {
    "revision": "1ce7567af0646789e31e",
    "url": "/static/js/35.dbfcdd30.chunk.js"
  },
  {
    "revision": "cbc45134fa55f38dde3f",
    "url": "/static/js/36.a2b3e4eb.chunk.js"
  },
  {
    "revision": "c5e30cc6c2b85a71698f",
    "url": "/static/js/37.8de60767.chunk.js"
  },
  {
    "revision": "31d2c2655157bd5d8541",
    "url": "/static/js/38.65107ca1.chunk.js"
  },
  {
    "revision": "98060e594fff013d3764",
    "url": "/static/js/39.6806c7d9.chunk.js"
  },
  {
    "revision": "9ac9d45dfb2eda117f4a",
    "url": "/static/js/4.ed3fc5b3.chunk.js"
  },
  {
    "revision": "ff73d95029c5988823d5",
    "url": "/static/js/40.3568f89b.chunk.js"
  },
  {
    "revision": "9a929aa2244926fea704",
    "url": "/static/js/41.acd78540.chunk.js"
  },
  {
    "revision": "73665516d954715a5640",
    "url": "/static/js/42.e90a3b79.chunk.js"
  },
  {
    "revision": "95fbd83e8d57ba1699f1",
    "url": "/static/js/43.2f747ae8.chunk.js"
  },
  {
    "revision": "7c04927d37cf96170459",
    "url": "/static/js/44.2a27e220.chunk.js"
  },
  {
    "revision": "fa4362dff6f07acb35e9",
    "url": "/static/js/45.56305108.chunk.js"
  },
  {
    "revision": "ac14c581a1013b336821",
    "url": "/static/js/46.1d6b0702.chunk.js"
  },
  {
    "revision": "496ea82965b7105b6214",
    "url": "/static/js/47.d4c26361.chunk.js"
  },
  {
    "revision": "639093a0dd18a2d883ad",
    "url": "/static/js/48.f8943ac7.chunk.js"
  },
  {
    "revision": "d4357f89e667b7d24b91",
    "url": "/static/js/49.133c2b34.chunk.js"
  },
  {
    "revision": "86d5eb605ec8dc14e6ca",
    "url": "/static/js/5.aa0bdaa3.chunk.js"
  },
  {
    "revision": "74753fc8f54f13e5706a",
    "url": "/static/js/50.3bad57ae.chunk.js"
  },
  {
    "revision": "f6e4e7fbab4895b3a589",
    "url": "/static/js/51.cd6249c3.chunk.js"
  },
  {
    "revision": "f4f63fb864be4af16baf",
    "url": "/static/js/52.a6069589.chunk.js"
  },
  {
    "revision": "7602103bc62bac6c8ad3",
    "url": "/static/js/53.ce395ad5.chunk.js"
  },
  {
    "revision": "9723d51dddf5c069eca9",
    "url": "/static/js/54.9f090d14.chunk.js"
  },
  {
    "revision": "bac7d84ddba132892e9c",
    "url": "/static/js/55.b3731bd0.chunk.js"
  },
  {
    "revision": "1f1e68da53e98797a77c",
    "url": "/static/js/56.23de0cd8.chunk.js"
  },
  {
    "revision": "5cd7da90a60e06c7ecef",
    "url": "/static/js/57.c4add612.chunk.js"
  },
  {
    "revision": "be391a1b1012525775ab",
    "url": "/static/js/58.32cf6ce5.chunk.js"
  },
  {
    "revision": "faa1b41ff4ac8eb2a487",
    "url": "/static/js/59.6097fdda.chunk.js"
  },
  {
    "revision": "bf0de8c469d3f5bf3ffe",
    "url": "/static/js/6.f00f7d39.chunk.js"
  },
  {
    "revision": "38acec6b8c2178aeef0a",
    "url": "/static/js/60.3b2e6e13.chunk.js"
  },
  {
    "revision": "df1bd14032fa433d1bb1",
    "url": "/static/js/61.f166cb31.chunk.js"
  },
  {
    "revision": "ef72b91cb7e23742f7de",
    "url": "/static/js/62.82fd5196.chunk.js"
  },
  {
    "revision": "b8260ebf7c8e1dd6fdb2",
    "url": "/static/js/63.7c016944.chunk.js"
  },
  {
    "revision": "a41e0d5ea21aa5e234dd",
    "url": "/static/js/64.6835bd35.chunk.js"
  },
  {
    "revision": "ee103bfb0aa7d1ce61fd",
    "url": "/static/js/65.c9c9ee0f.chunk.js"
  },
  {
    "revision": "6e912b75d6cdfd94c7d0",
    "url": "/static/js/66.3ef01e79.chunk.js"
  },
  {
    "revision": "ec40e6eac55232276749",
    "url": "/static/js/67.9d4a87e0.chunk.js"
  },
  {
    "revision": "d1a79058ef2cfd715af3",
    "url": "/static/js/68.e9f58802.chunk.js"
  },
  {
    "revision": "a19ca39cbae196324262",
    "url": "/static/js/69.96b15d2f.chunk.js"
  },
  {
    "revision": "5d8dedbc78c2bcf8e23e",
    "url": "/static/js/7.021620ed.chunk.js"
  },
  {
    "revision": "fdce536bba9e54831df7",
    "url": "/static/js/70.bba2f6e0.chunk.js"
  },
  {
    "revision": "0d226aa2c27f2af6cc62",
    "url": "/static/js/71.b16d832d.chunk.js"
  },
  {
    "revision": "9087e03f709d116514f8",
    "url": "/static/js/72.ef1b97b5.chunk.js"
  },
  {
    "revision": "9f5171f0bef4b3adc1b3",
    "url": "/static/js/73.06ba0ebe.chunk.js"
  },
  {
    "revision": "2f58266c41d9553956b7",
    "url": "/static/js/74.074caba4.chunk.js"
  },
  {
    "revision": "bb2e61e1830d37673503",
    "url": "/static/js/75.1325ae83.chunk.js"
  },
  {
    "revision": "4e0e311e66fcc2ee46bb",
    "url": "/static/js/76.1a409d69.chunk.js"
  },
  {
    "revision": "fa75d8ebfc468d390c4a",
    "url": "/static/js/77.6e23605c.chunk.js"
  },
  {
    "revision": "a27a3b31471b46155e19",
    "url": "/static/js/78.ecfbaa60.chunk.js"
  },
  {
    "revision": "fa298baf93130d5d9f25",
    "url": "/static/js/79.501d8bac.chunk.js"
  },
  {
    "revision": "f5f559859a3384f56d06",
    "url": "/static/js/8.c18f5549.chunk.js"
  },
  {
    "revision": "3d82cbb199104db7f493",
    "url": "/static/js/80.8649a7e0.chunk.js"
  },
  {
    "revision": "0673de137840a1e9151e",
    "url": "/static/js/81.be617c32.chunk.js"
  },
  {
    "revision": "b3a4bbbc8478585f8b0c",
    "url": "/static/js/9.1fb13bf9.chunk.js"
  },
  {
    "revision": "ec3c3da7a7c6acb1c48d",
    "url": "/static/js/main.c44dfdd5.chunk.js"
  },
  {
    "revision": "c95e95d1e98329dbe6f4",
    "url": "/static/js/runtime-main.968d22ac.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);