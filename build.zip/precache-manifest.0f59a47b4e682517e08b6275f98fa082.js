self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4b63c4e5a958a6b88753ae89b24ae9ac",
    "url": "/index.html"
  },
  {
    "revision": "f08bfb3de7f8690f45cd",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "fc62391d468847438095",
    "url": "/static/css/11.2e947bf2.chunk.css"
  },
  {
    "revision": "43d1b826407e280d706d",
    "url": "/static/css/12.5ca8bf9f.chunk.css"
  },
  {
    "revision": "bcc64d8b167fa0ad509c",
    "url": "/static/css/13.ac09eb94.chunk.css"
  },
  {
    "revision": "0fd7e3e309bc51e4d931",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "f08bfb3de7f8690f45cd",
    "url": "/static/js/0.e0cec191.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.e0cec191.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6c7f6003fc35ea596905",
    "url": "/static/js/1.415dc13c.chunk.js"
  },
  {
    "revision": "fc62391d468847438095",
    "url": "/static/js/11.68f040be.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/11.68f040be.chunk.js.LICENSE.txt"
  },
  {
    "revision": "43d1b826407e280d706d",
    "url": "/static/js/12.4d58d5d1.chunk.js"
  },
  {
    "revision": "bcc64d8b167fa0ad509c",
    "url": "/static/js/13.f5e45da6.chunk.js"
  },
  {
    "revision": "d49c58d05a952771b943",
    "url": "/static/js/14.e8ef4a81.chunk.js"
  },
  {
    "revision": "ac253bd280fb19159fe5",
    "url": "/static/js/15.d9be14de.chunk.js"
  },
  {
    "revision": "5fe56a9b4c9dcc8709f5",
    "url": "/static/js/16.db9203c5.chunk.js"
  },
  {
    "revision": "ee97a192deede3d681e9",
    "url": "/static/js/17.cdcfc6c2.chunk.js"
  },
  {
    "revision": "750a08bbfd7b012df260",
    "url": "/static/js/18.2802e595.chunk.js"
  },
  {
    "revision": "724d0867d06e0cd48b2c",
    "url": "/static/js/19.866b517f.chunk.js"
  },
  {
    "revision": "48a07695195fda2cd330",
    "url": "/static/js/2.9ac9300e.chunk.js"
  },
  {
    "revision": "a4b7546dcc1aad146a88",
    "url": "/static/js/20.5d72e0e8.chunk.js"
  },
  {
    "revision": "14008a9e19b89057389c",
    "url": "/static/js/21.bab0d2db.chunk.js"
  },
  {
    "revision": "3fe47ff41c6a527b691e",
    "url": "/static/js/22.0c277d8a.chunk.js"
  },
  {
    "revision": "ec7afae4acc875a63288",
    "url": "/static/js/23.df513f94.chunk.js"
  },
  {
    "revision": "5419fc8579ea823108ca",
    "url": "/static/js/24.37e4d152.chunk.js"
  },
  {
    "revision": "78b2b05c0234ae438826",
    "url": "/static/js/25.a1566b8f.chunk.js"
  },
  {
    "revision": "da04285e0571b5cda407",
    "url": "/static/js/26.73ec9d8a.chunk.js"
  },
  {
    "revision": "80fc8b1eaffc22bc230c",
    "url": "/static/js/27.5d47df3b.chunk.js"
  },
  {
    "revision": "1dff91ac911deed2aa68",
    "url": "/static/js/28.7a744420.chunk.js"
  },
  {
    "revision": "303c5b33768b368d076d",
    "url": "/static/js/29.a4e0da2c.chunk.js"
  },
  {
    "revision": "2dcad09eccb5430e4612",
    "url": "/static/js/3.cafe5f51.chunk.js"
  },
  {
    "revision": "577aea221e73f4f111ad",
    "url": "/static/js/30.9f32b496.chunk.js"
  },
  {
    "revision": "da350a0a481c1c7310d0",
    "url": "/static/js/31.491b0b58.chunk.js"
  },
  {
    "revision": "9707e31c3aae810c9abf",
    "url": "/static/js/32.bac3bfc4.chunk.js"
  },
  {
    "revision": "dea7331f63a32eb4eba4",
    "url": "/static/js/33.f90edaf2.chunk.js"
  },
  {
    "revision": "a5ba7f434f0d5c0f0f83",
    "url": "/static/js/34.3d2f29b2.chunk.js"
  },
  {
    "revision": "5bdf5cef716ff3e10b02",
    "url": "/static/js/35.f66bce2b.chunk.js"
  },
  {
    "revision": "a8894d1e3a25b4a64bd3",
    "url": "/static/js/36.6b8217d7.chunk.js"
  },
  {
    "revision": "2296877f5cf4bcf34875",
    "url": "/static/js/37.26bcffb0.chunk.js"
  },
  {
    "revision": "50f5a65012452464c9a9",
    "url": "/static/js/38.fc8fe627.chunk.js"
  },
  {
    "revision": "2e4b6df0c52c09b5b011",
    "url": "/static/js/39.12bab215.chunk.js"
  },
  {
    "revision": "b7c0acaf04285a9c29c4",
    "url": "/static/js/4.42c1df58.chunk.js"
  },
  {
    "revision": "0a3c654ed78b8d9cfb7c",
    "url": "/static/js/40.53b204aa.chunk.js"
  },
  {
    "revision": "59a8488ffa3cd823448c",
    "url": "/static/js/41.66e58cc1.chunk.js"
  },
  {
    "revision": "82eb6b4c1b8af395ffd8",
    "url": "/static/js/42.60982059.chunk.js"
  },
  {
    "revision": "9d316bd5d6fcb86a50f2",
    "url": "/static/js/43.ad9c3271.chunk.js"
  },
  {
    "revision": "8de3e3a6049dd53781e3",
    "url": "/static/js/44.a2155423.chunk.js"
  },
  {
    "revision": "032eca523f9e2e87ced5",
    "url": "/static/js/45.d5220f69.chunk.js"
  },
  {
    "revision": "d689518d4c4579b6fb8b",
    "url": "/static/js/46.f0a7b9f4.chunk.js"
  },
  {
    "revision": "0584826e0e21d57668d0",
    "url": "/static/js/47.233801d6.chunk.js"
  },
  {
    "revision": "01f5bc63d525a119166f",
    "url": "/static/js/48.49c8ff38.chunk.js"
  },
  {
    "revision": "d123b7766f1d5eac283c",
    "url": "/static/js/49.2dd1500b.chunk.js"
  },
  {
    "revision": "156905716c0aff5cab2f",
    "url": "/static/js/5.8ec6920d.chunk.js"
  },
  {
    "revision": "28d7628c2f34f2ef7ea1",
    "url": "/static/js/50.f5e5a59f.chunk.js"
  },
  {
    "revision": "dbf235b58bc7b1256ea5",
    "url": "/static/js/51.a71d0845.chunk.js"
  },
  {
    "revision": "0aa0811c34840fbec747",
    "url": "/static/js/52.852f3d64.chunk.js"
  },
  {
    "revision": "dd3e4c6b2a44eeeb32cc",
    "url": "/static/js/53.e8646f5d.chunk.js"
  },
  {
    "revision": "5d6a13a82700eca293f5",
    "url": "/static/js/54.368fd490.chunk.js"
  },
  {
    "revision": "9cdab496e21a2d2f024a",
    "url": "/static/js/55.c3f5cf83.chunk.js"
  },
  {
    "revision": "fee2865beee071166ece",
    "url": "/static/js/56.df990d84.chunk.js"
  },
  {
    "revision": "24463df6bce57834c560",
    "url": "/static/js/57.c2bec197.chunk.js"
  },
  {
    "revision": "23034da2aea1045d7af3",
    "url": "/static/js/58.32f2395e.chunk.js"
  },
  {
    "revision": "b48fb75fe8d3cee14326",
    "url": "/static/js/59.2072e9d2.chunk.js"
  },
  {
    "revision": "c1c377a49140d471b5ca",
    "url": "/static/js/6.8dac53f7.chunk.js"
  },
  {
    "revision": "6e3265b0f43172f1aa3c",
    "url": "/static/js/60.9b5bb34c.chunk.js"
  },
  {
    "revision": "523004ef773de62bb049",
    "url": "/static/js/61.5f6a19f5.chunk.js"
  },
  {
    "revision": "86db5642fb7e03244899",
    "url": "/static/js/62.7043127d.chunk.js"
  },
  {
    "revision": "b0301f596787f4dcfa3a",
    "url": "/static/js/63.22531a1e.chunk.js"
  },
  {
    "revision": "efa4d40d4541fe013206",
    "url": "/static/js/64.1f70e637.chunk.js"
  },
  {
    "revision": "ee6761071511b371de6d",
    "url": "/static/js/65.a19e155a.chunk.js"
  },
  {
    "revision": "e89e01af04b5d80372e8",
    "url": "/static/js/66.ca995248.chunk.js"
  },
  {
    "revision": "e06620b9db776afb14d5",
    "url": "/static/js/67.611707c4.chunk.js"
  },
  {
    "revision": "5f3ccb51e6c564168063",
    "url": "/static/js/68.e78dca8b.chunk.js"
  },
  {
    "revision": "7cd17cd85c4d120e118b",
    "url": "/static/js/69.a00712a4.chunk.js"
  },
  {
    "revision": "43776b760ab44e76c43f",
    "url": "/static/js/7.e7ab3369.chunk.js"
  },
  {
    "revision": "24a520a9d10d60b0eef4",
    "url": "/static/js/70.7a2e929f.chunk.js"
  },
  {
    "revision": "b03bac5c272306d0546d",
    "url": "/static/js/71.e2d94938.chunk.js"
  },
  {
    "revision": "baf7297d4cf4df6a8928",
    "url": "/static/js/72.13c29efd.chunk.js"
  },
  {
    "revision": "738d8b056b1f444b52c5",
    "url": "/static/js/73.47d02c4d.chunk.js"
  },
  {
    "revision": "052d983bb985adcf9167",
    "url": "/static/js/74.8d62a7c1.chunk.js"
  },
  {
    "revision": "375e8490a03444034ef8",
    "url": "/static/js/75.55a608a8.chunk.js"
  },
  {
    "revision": "7981355d13215c9d92c5",
    "url": "/static/js/76.823b751f.chunk.js"
  },
  {
    "revision": "643eef77c9aedbb91edf",
    "url": "/static/js/8.dfefa827.chunk.js"
  },
  {
    "revision": "0fd7e3e309bc51e4d931",
    "url": "/static/js/main.b087ed4b.chunk.js"
  },
  {
    "revision": "8aad82c1c4a5616cf0f9",
    "url": "/static/js/runtime-main.0c41b1db.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);