self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c707799edb21d88b1f12c4044c5f8ae9",
    "url": "/index.html"
  },
  {
    "revision": "1d5817abed4dcd561382",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "b09524ab73a8a9eef5c1",
    "url": "/static/css/14.2e947bf2.chunk.css"
  },
  {
    "revision": "9f59186b050c34554a69",
    "url": "/static/css/15.c82eef1a.chunk.css"
  },
  {
    "revision": "5506b1a0f03601192970",
    "url": "/static/css/16.ac09eb94.chunk.css"
  },
  {
    "revision": "30f5c30952422d0886d4",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "1d5817abed4dcd561382",
    "url": "/static/js/0.222d1646.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.222d1646.chunk.js.LICENSE.txt"
  },
  {
    "revision": "67cecdbe359f93933295",
    "url": "/static/js/1.c755569d.chunk.js"
  },
  {
    "revision": "00261ab564d4a2cb0d05",
    "url": "/static/js/10.3cf79cee.chunk.js"
  },
  {
    "revision": "18d6312f3689fde18158",
    "url": "/static/js/11.94569b2f.chunk.js"
  },
  {
    "revision": "b09524ab73a8a9eef5c1",
    "url": "/static/js/14.ca19482f.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/14.ca19482f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9f59186b050c34554a69",
    "url": "/static/js/15.3270ccc6.chunk.js"
  },
  {
    "revision": "5506b1a0f03601192970",
    "url": "/static/js/16.f15a0d88.chunk.js"
  },
  {
    "revision": "be66cbc1f02439d8f19b",
    "url": "/static/js/17.503a52aa.chunk.js"
  },
  {
    "revision": "c1ed9d02d8be9a5cb4f7",
    "url": "/static/js/18.b5f84803.chunk.js"
  },
  {
    "revision": "f5ed54f42cde956c5e0d",
    "url": "/static/js/19.37a900b0.chunk.js"
  },
  {
    "revision": "b08b7fe41d58d394d685",
    "url": "/static/js/2.da1fe974.chunk.js"
  },
  {
    "revision": "e171082824b4b7b626b9",
    "url": "/static/js/20.8d779052.chunk.js"
  },
  {
    "revision": "f3c40933f03fcda70755",
    "url": "/static/js/21.22ec68a3.chunk.js"
  },
  {
    "revision": "14b4a9e792169e4363ba",
    "url": "/static/js/22.cfbac973.chunk.js"
  },
  {
    "revision": "9381ac305c9a7184cf6f",
    "url": "/static/js/23.b3acf5f5.chunk.js"
  },
  {
    "revision": "6aa3013f3fb3f4b04165",
    "url": "/static/js/24.3fa663f3.chunk.js"
  },
  {
    "revision": "08aa2df75a405e009c15",
    "url": "/static/js/25.4ea06875.chunk.js"
  },
  {
    "revision": "980d092cdb2084425f7b",
    "url": "/static/js/26.c47418f0.chunk.js"
  },
  {
    "revision": "a2b0565ec853ef8790c9",
    "url": "/static/js/27.ffe1291e.chunk.js"
  },
  {
    "revision": "3b7cd92ea1ce7f8b1ebc",
    "url": "/static/js/28.669ab3c2.chunk.js"
  },
  {
    "revision": "7eb57f6aebf381761fb5",
    "url": "/static/js/29.73600a41.chunk.js"
  },
  {
    "revision": "5c32f6d0761106ece79b",
    "url": "/static/js/3.eb13577b.chunk.js"
  },
  {
    "revision": "aab9578ec09b7b06b505",
    "url": "/static/js/30.f12a9aff.chunk.js"
  },
  {
    "revision": "b40b4cbdfee807829e54",
    "url": "/static/js/31.5df5f310.chunk.js"
  },
  {
    "revision": "a844400a9f229f4fa2e7",
    "url": "/static/js/32.85a355a6.chunk.js"
  },
  {
    "revision": "8635cf426c147580bbd9",
    "url": "/static/js/33.d314c2b2.chunk.js"
  },
  {
    "revision": "6e59fdaac1c97c03cd50",
    "url": "/static/js/34.aaa582bd.chunk.js"
  },
  {
    "revision": "789bce044d06be3eb748",
    "url": "/static/js/35.54e181dc.chunk.js"
  },
  {
    "revision": "aa7bad032a9694d5c086",
    "url": "/static/js/36.989ee621.chunk.js"
  },
  {
    "revision": "da233d84a80e1341d0ab",
    "url": "/static/js/37.9ce024a2.chunk.js"
  },
  {
    "revision": "a7e5be9a74ba61302837",
    "url": "/static/js/38.2c3a51b8.chunk.js"
  },
  {
    "revision": "a5ca57067c64b488f0fb",
    "url": "/static/js/39.473d808d.chunk.js"
  },
  {
    "revision": "126e8d586303810eeced",
    "url": "/static/js/4.55fe0212.chunk.js"
  },
  {
    "revision": "43b57e08e4c89f251309",
    "url": "/static/js/40.9793a7a6.chunk.js"
  },
  {
    "revision": "56c1ae1dbb8b10bcd7cc",
    "url": "/static/js/41.21392d01.chunk.js"
  },
  {
    "revision": "c69858e6469edb985b2b",
    "url": "/static/js/42.bbd6e27e.chunk.js"
  },
  {
    "revision": "51506dbf5a363466a8db",
    "url": "/static/js/43.041870c1.chunk.js"
  },
  {
    "revision": "2977101c252e904ca02b",
    "url": "/static/js/44.4461dbfb.chunk.js"
  },
  {
    "revision": "065e6a09723f23648f60",
    "url": "/static/js/45.e09cb885.chunk.js"
  },
  {
    "revision": "3269f59c526e6cfa77f7",
    "url": "/static/js/46.c4898e48.chunk.js"
  },
  {
    "revision": "685b1d2624454370168f",
    "url": "/static/js/47.29d754e5.chunk.js"
  },
  {
    "revision": "5e020aa8dd44176062c2",
    "url": "/static/js/48.82708c10.chunk.js"
  },
  {
    "revision": "2d0996d0e97ad038bf82",
    "url": "/static/js/49.26efd72b.chunk.js"
  },
  {
    "revision": "f836736a5cce4cdfec01",
    "url": "/static/js/5.7787c306.chunk.js"
  },
  {
    "revision": "2a38cfbc129b1b955071",
    "url": "/static/js/50.fe70247e.chunk.js"
  },
  {
    "revision": "61c15d9a22d5b5aa462b",
    "url": "/static/js/51.31c5eeaf.chunk.js"
  },
  {
    "revision": "2a0d1ad8efa6633e0311",
    "url": "/static/js/52.98591f16.chunk.js"
  },
  {
    "revision": "5b8554bc820cc2394b74",
    "url": "/static/js/53.4b188a58.chunk.js"
  },
  {
    "revision": "92771b2a1820431a281e",
    "url": "/static/js/54.d1457c3a.chunk.js"
  },
  {
    "revision": "6832ac3e65e97f949943",
    "url": "/static/js/55.ff2279a8.chunk.js"
  },
  {
    "revision": "74ab6ffa2d706fc5ab6e",
    "url": "/static/js/56.b0c4a901.chunk.js"
  },
  {
    "revision": "9a155f250eb5ca41fc2a",
    "url": "/static/js/57.df157198.chunk.js"
  },
  {
    "revision": "494ee2c553149e066a6b",
    "url": "/static/js/58.b99d5957.chunk.js"
  },
  {
    "revision": "c302a2a90a2a48fe5aae",
    "url": "/static/js/59.c1d7c9d7.chunk.js"
  },
  {
    "revision": "99297bc1bd3d4ceccb21",
    "url": "/static/js/6.8ffbcaeb.chunk.js"
  },
  {
    "revision": "27ad4be423eeea7bc5f7",
    "url": "/static/js/60.6d522552.chunk.js"
  },
  {
    "revision": "8e81b3f2a0c360d27471",
    "url": "/static/js/61.544bc08e.chunk.js"
  },
  {
    "revision": "c2ddbd599ffa74833677",
    "url": "/static/js/62.d7c4c554.chunk.js"
  },
  {
    "revision": "78e0563e36ffe5f83bdf",
    "url": "/static/js/63.7e19a8a1.chunk.js"
  },
  {
    "revision": "bfef8febba6a4bca3c85",
    "url": "/static/js/64.8190e5a6.chunk.js"
  },
  {
    "revision": "c2f799e678333bc1da35",
    "url": "/static/js/65.9fc10702.chunk.js"
  },
  {
    "revision": "ca04fd9f06e9e38384c8",
    "url": "/static/js/66.6e6d6b72.chunk.js"
  },
  {
    "revision": "3fdfbc98546af45033ab",
    "url": "/static/js/67.0962ba94.chunk.js"
  },
  {
    "revision": "8ce64d753af7c3b7c9ec",
    "url": "/static/js/68.124d9a6e.chunk.js"
  },
  {
    "revision": "de3b44a53c81206a7ea6",
    "url": "/static/js/69.43826089.chunk.js"
  },
  {
    "revision": "1afd95b91ed53a0cc0b4",
    "url": "/static/js/7.de4ff7c8.chunk.js"
  },
  {
    "revision": "ea33470350d27948aa58",
    "url": "/static/js/70.71ab8987.chunk.js"
  },
  {
    "revision": "ab9c7cdc57cdaa4c4a21",
    "url": "/static/js/71.223a8115.chunk.js"
  },
  {
    "revision": "dbfaab39c4406a69ef77",
    "url": "/static/js/72.a68957f6.chunk.js"
  },
  {
    "revision": "dc6d1e38b8142e03994f",
    "url": "/static/js/73.90040641.chunk.js"
  },
  {
    "revision": "823c07586586a654c9c0",
    "url": "/static/js/74.034b46a8.chunk.js"
  },
  {
    "revision": "651fa38c8f698cc1d022",
    "url": "/static/js/75.e047b491.chunk.js"
  },
  {
    "revision": "83967e7ada695af18aa9",
    "url": "/static/js/76.014aed1f.chunk.js"
  },
  {
    "revision": "4ec76147f62afd679513",
    "url": "/static/js/77.9bd3306d.chunk.js"
  },
  {
    "revision": "6aaf22279b1e590b03f5",
    "url": "/static/js/78.9a830028.chunk.js"
  },
  {
    "revision": "549371d68e34ae8dd97c",
    "url": "/static/js/79.e1765600.chunk.js"
  },
  {
    "revision": "13badd63822cdde2ba22",
    "url": "/static/js/8.1f59bedd.chunk.js"
  },
  {
    "revision": "48133578c842de7d6fc5",
    "url": "/static/js/80.03e3a095.chunk.js"
  },
  {
    "revision": "0504106eb79d898f1b5e",
    "url": "/static/js/81.640d11d9.chunk.js"
  },
  {
    "revision": "29cbeaa0bbfa3cd1d4c7",
    "url": "/static/js/82.2ce1ba5a.chunk.js"
  },
  {
    "revision": "65b81d57d6d0fd61027d",
    "url": "/static/js/9.fa2c1ade.chunk.js"
  },
  {
    "revision": "30f5c30952422d0886d4",
    "url": "/static/js/main.ed3ffbc6.chunk.js"
  },
  {
    "revision": "69d5aed36ff4f4ef0d63",
    "url": "/static/js/runtime-main.3fef43d3.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);