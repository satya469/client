self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "71a523000177347936dafdddeddf996a",
    "url": "/index.html"
  },
  {
    "revision": "00589fabcbfe15f466d9",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "bb1d0d781b5fbf570682",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "8fe5d1e9c18b0df6fa64",
    "url": "/static/css/14.b2f7c587.chunk.css"
  },
  {
    "revision": "fa16e13233426d687f9c",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "afc5a183ff5b0115c17d",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "00589fabcbfe15f466d9",
    "url": "/static/js/0.0a5cd05f.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.0a5cd05f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "88fcaded5160a4046add",
    "url": "/static/js/1.6e7312e1.chunk.js"
  },
  {
    "revision": "7887f055830f33be3934",
    "url": "/static/js/10.dc53e043.chunk.js"
  },
  {
    "revision": "bb1d0d781b5fbf570682",
    "url": "/static/js/13.141e4783.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.141e4783.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8fe5d1e9c18b0df6fa64",
    "url": "/static/js/14.5371cd05.chunk.js"
  },
  {
    "revision": "fa16e13233426d687f9c",
    "url": "/static/js/15.a58c989a.chunk.js"
  },
  {
    "revision": "91ae6edbacb6cbf1fc8e",
    "url": "/static/js/16.52c22b6f.chunk.js"
  },
  {
    "revision": "7a132662a47e841d2d69",
    "url": "/static/js/17.7d6005eb.chunk.js"
  },
  {
    "revision": "70dd3bc0f4b9a68e474a",
    "url": "/static/js/18.f88f85ff.chunk.js"
  },
  {
    "revision": "0e641381c3e9a1606cd4",
    "url": "/static/js/19.687e0584.chunk.js"
  },
  {
    "revision": "f7b80733d6e96031700d",
    "url": "/static/js/2.f6da7b85.chunk.js"
  },
  {
    "revision": "30f80bf81c01917085af",
    "url": "/static/js/20.d5d7b186.chunk.js"
  },
  {
    "revision": "ddecb2e974aea43f2275",
    "url": "/static/js/21.3b886fe8.chunk.js"
  },
  {
    "revision": "7d0fe5fff7e95bc2a171",
    "url": "/static/js/22.2eaa6c6e.chunk.js"
  },
  {
    "revision": "3d988726ca133efb883c",
    "url": "/static/js/23.e4330365.chunk.js"
  },
  {
    "revision": "848f27e9fb014cc20163",
    "url": "/static/js/24.1d826edc.chunk.js"
  },
  {
    "revision": "54d13314535d01b55ff7",
    "url": "/static/js/25.0b366aa4.chunk.js"
  },
  {
    "revision": "fc915cd766ad23415df6",
    "url": "/static/js/26.bff274dd.chunk.js"
  },
  {
    "revision": "a4b939c05657cb05a898",
    "url": "/static/js/27.c4a5da3c.chunk.js"
  },
  {
    "revision": "d81cac5ee2d61246e517",
    "url": "/static/js/28.c3c089f6.chunk.js"
  },
  {
    "revision": "28601c27b0a5a21757f3",
    "url": "/static/js/29.405bd040.chunk.js"
  },
  {
    "revision": "20a9ade82222e877aa03",
    "url": "/static/js/3.b007ca56.chunk.js"
  },
  {
    "revision": "eebb73aaa2613915cea7",
    "url": "/static/js/30.53f74bc0.chunk.js"
  },
  {
    "revision": "bf04e10859515d484a8e",
    "url": "/static/js/31.5a858840.chunk.js"
  },
  {
    "revision": "ad88b6f2122aea0c03f1",
    "url": "/static/js/32.28726265.chunk.js"
  },
  {
    "revision": "8c11410b002e80c976a1",
    "url": "/static/js/33.3f470c52.chunk.js"
  },
  {
    "revision": "d423e5ba03bbfea5c35d",
    "url": "/static/js/34.db4b28c9.chunk.js"
  },
  {
    "revision": "71dadfb861482be5ea7d",
    "url": "/static/js/35.32a66b22.chunk.js"
  },
  {
    "revision": "f79c1b3fbb07b9f03e6b",
    "url": "/static/js/36.63f625ed.chunk.js"
  },
  {
    "revision": "bd7a843c31f9f06d73eb",
    "url": "/static/js/37.22fc62b8.chunk.js"
  },
  {
    "revision": "f68f53551bdc24e124af",
    "url": "/static/js/38.49197172.chunk.js"
  },
  {
    "revision": "c401167d95de357aad87",
    "url": "/static/js/39.84073c26.chunk.js"
  },
  {
    "revision": "19d48cc70e5e052eb1cc",
    "url": "/static/js/4.b4569ed8.chunk.js"
  },
  {
    "revision": "43b6dcbbb471118583bb",
    "url": "/static/js/40.cace405c.chunk.js"
  },
  {
    "revision": "1500cdf42be1b935454c",
    "url": "/static/js/41.1ee5e8dd.chunk.js"
  },
  {
    "revision": "d4d96f65fb3d021f8244",
    "url": "/static/js/42.6fe8d2e6.chunk.js"
  },
  {
    "revision": "6c4f621de6c7768d41f9",
    "url": "/static/js/43.9197c2a1.chunk.js"
  },
  {
    "revision": "99b54367ae33115b0080",
    "url": "/static/js/44.1de15b8b.chunk.js"
  },
  {
    "revision": "3b5fbc59d8260e73deb7",
    "url": "/static/js/45.03de6da1.chunk.js"
  },
  {
    "revision": "bbcc7c0d69705a629813",
    "url": "/static/js/46.37db73ac.chunk.js"
  },
  {
    "revision": "e28ccbfb465bc8cbaf0c",
    "url": "/static/js/47.5919a306.chunk.js"
  },
  {
    "revision": "07a5843e1ccf513c7cf7",
    "url": "/static/js/48.34e1fac2.chunk.js"
  },
  {
    "revision": "7e180bd47762d3c743af",
    "url": "/static/js/49.dadb0eb2.chunk.js"
  },
  {
    "revision": "ef367ad98f19ea94321c",
    "url": "/static/js/5.96def78b.chunk.js"
  },
  {
    "revision": "6304c8202a06c815ec6b",
    "url": "/static/js/50.2c29d40f.chunk.js"
  },
  {
    "revision": "b27db4aa03ec63e7ac23",
    "url": "/static/js/51.438973b2.chunk.js"
  },
  {
    "revision": "e51eb607595bcea9b838",
    "url": "/static/js/52.c3f72b9e.chunk.js"
  },
  {
    "revision": "39db9a6d974d3baa6d04",
    "url": "/static/js/53.b53f1ed8.chunk.js"
  },
  {
    "revision": "c864c102e4fb3f0b1afb",
    "url": "/static/js/54.5385dfc0.chunk.js"
  },
  {
    "revision": "70fc81f37c9d2e55ee6a",
    "url": "/static/js/55.fe249991.chunk.js"
  },
  {
    "revision": "0a5d3bcb9da930e72b79",
    "url": "/static/js/56.6ab8c594.chunk.js"
  },
  {
    "revision": "edf37a14f35ecdc6c8d7",
    "url": "/static/js/57.19a6a2bc.chunk.js"
  },
  {
    "revision": "9a93993f295fc601a54e",
    "url": "/static/js/58.445d6bde.chunk.js"
  },
  {
    "revision": "0766b0a8b0754f89f115",
    "url": "/static/js/59.010f8bb1.chunk.js"
  },
  {
    "revision": "57ca85f712b0289d820b",
    "url": "/static/js/6.724f04df.chunk.js"
  },
  {
    "revision": "be84567c92ee5f4fe509",
    "url": "/static/js/60.12fd5997.chunk.js"
  },
  {
    "revision": "8a62df163d3a270bcf56",
    "url": "/static/js/61.d5a02085.chunk.js"
  },
  {
    "revision": "8520e317e5308b9c2da2",
    "url": "/static/js/62.0ecaa635.chunk.js"
  },
  {
    "revision": "a9da65b36f39d1e8fee3",
    "url": "/static/js/63.fa30323c.chunk.js"
  },
  {
    "revision": "917c8ed6decdb0cb132b",
    "url": "/static/js/64.62c0ccb6.chunk.js"
  },
  {
    "revision": "26d9b7a2f445a8458e98",
    "url": "/static/js/65.3bcc3972.chunk.js"
  },
  {
    "revision": "c28c249c102faa937ab4",
    "url": "/static/js/66.8c621261.chunk.js"
  },
  {
    "revision": "9db4ab82725d2250f2a7",
    "url": "/static/js/67.f3c1d48f.chunk.js"
  },
  {
    "revision": "f03c1f18a06634229c73",
    "url": "/static/js/68.0a8b90ed.chunk.js"
  },
  {
    "revision": "f30ca4b979e6e169c597",
    "url": "/static/js/69.cc554fa9.chunk.js"
  },
  {
    "revision": "e3b39bf17b1b03c5cb53",
    "url": "/static/js/7.afa44608.chunk.js"
  },
  {
    "revision": "bbd443c013fc06642110",
    "url": "/static/js/70.dd4e02ea.chunk.js"
  },
  {
    "revision": "212e930eb78c71e1a1e9",
    "url": "/static/js/71.a990e7d5.chunk.js"
  },
  {
    "revision": "911ece303b44bb7e7cf4",
    "url": "/static/js/72.43c041fe.chunk.js"
  },
  {
    "revision": "674a502dc6fb7d2fd5e8",
    "url": "/static/js/73.172f65e2.chunk.js"
  },
  {
    "revision": "d3bdf40935da9737ba59",
    "url": "/static/js/74.35ec2255.chunk.js"
  },
  {
    "revision": "4fb28a76506c0eefc098",
    "url": "/static/js/75.d1a7a20a.chunk.js"
  },
  {
    "revision": "829a8d42d6fdd3763765",
    "url": "/static/js/76.02128d46.chunk.js"
  },
  {
    "revision": "1a7238df54475f25d13b",
    "url": "/static/js/77.2df067e1.chunk.js"
  },
  {
    "revision": "2025cd489e1bf166cf43",
    "url": "/static/js/78.a46aed44.chunk.js"
  },
  {
    "revision": "d19c62501a2499e28aa4",
    "url": "/static/js/79.0b14e4e2.chunk.js"
  },
  {
    "revision": "93ebd3607a9910568df2",
    "url": "/static/js/8.9244bbe4.chunk.js"
  },
  {
    "revision": "0a33195faab0d35af9d2",
    "url": "/static/js/80.f874cfa4.chunk.js"
  },
  {
    "revision": "e585cc1da1a0cbf81422",
    "url": "/static/js/81.16bb70e8.chunk.js"
  },
  {
    "revision": "0aba2eab9ea3ab82240e",
    "url": "/static/js/82.8039e8f8.chunk.js"
  },
  {
    "revision": "318d995d247111caa829",
    "url": "/static/js/83.5e22d566.chunk.js"
  },
  {
    "revision": "f6a1d9544ba2d884b02c",
    "url": "/static/js/9.5f9a648f.chunk.js"
  },
  {
    "revision": "afc5a183ff5b0115c17d",
    "url": "/static/js/main.1727f30f.chunk.js"
  },
  {
    "revision": "f19809cdd24204065fb7",
    "url": "/static/js/runtime-main.25c031c4.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b23df4db71a29dbb733a0e555a7db8f9",
    "url": "/static/media/feather.b23df4db.svg"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);