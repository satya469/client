self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fd5ef214d5a6552173010e6385269983",
    "url": "/index.html"
  },
  {
    "revision": "00589fabcbfe15f466d9",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "bb1d0d781b5fbf570682",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "c669e6a2faebc0ab842d",
    "url": "/static/css/14.d1cce438.chunk.css"
  },
  {
    "revision": "fa16e13233426d687f9c",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "3ea3e53d8944f64ec47c",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "00589fabcbfe15f466d9",
    "url": "/static/js/0.0a5cd05f.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.0a5cd05f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "88fcaded5160a4046add",
    "url": "/static/js/1.6e7312e1.chunk.js"
  },
  {
    "revision": "7887f055830f33be3934",
    "url": "/static/js/10.dc53e043.chunk.js"
  },
  {
    "revision": "bb1d0d781b5fbf570682",
    "url": "/static/js/13.141e4783.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.141e4783.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c669e6a2faebc0ab842d",
    "url": "/static/js/14.734f1f88.chunk.js"
  },
  {
    "revision": "fa16e13233426d687f9c",
    "url": "/static/js/15.a58c989a.chunk.js"
  },
  {
    "revision": "91ae6edbacb6cbf1fc8e",
    "url": "/static/js/16.52c22b6f.chunk.js"
  },
  {
    "revision": "731d4fcf47ff233344a0",
    "url": "/static/js/17.7f899265.chunk.js"
  },
  {
    "revision": "f299149cd873d940c48b",
    "url": "/static/js/18.37c1a809.chunk.js"
  },
  {
    "revision": "b81ab1b1257878169472",
    "url": "/static/js/19.479a6fdb.chunk.js"
  },
  {
    "revision": "f7b80733d6e96031700d",
    "url": "/static/js/2.f6da7b85.chunk.js"
  },
  {
    "revision": "30f80bf81c01917085af",
    "url": "/static/js/20.d5d7b186.chunk.js"
  },
  {
    "revision": "cd468b767d4359efa89b",
    "url": "/static/js/21.125f63c0.chunk.js"
  },
  {
    "revision": "d31cf353a4e9a0b8277e",
    "url": "/static/js/22.040a5deb.chunk.js"
  },
  {
    "revision": "c583b0cbf356094f678e",
    "url": "/static/js/23.f47f6562.chunk.js"
  },
  {
    "revision": "848f27e9fb014cc20163",
    "url": "/static/js/24.1d826edc.chunk.js"
  },
  {
    "revision": "8f3145762a1bc3e0ad97",
    "url": "/static/js/25.0fd6db66.chunk.js"
  },
  {
    "revision": "75d049ef1e1934996d7b",
    "url": "/static/js/26.dbdbb929.chunk.js"
  },
  {
    "revision": "a4b939c05657cb05a898",
    "url": "/static/js/27.c4a5da3c.chunk.js"
  },
  {
    "revision": "24a72db7ddce574db83b",
    "url": "/static/js/28.6dd7bc56.chunk.js"
  },
  {
    "revision": "9af53a196d12d5b338ed",
    "url": "/static/js/29.c09dd34d.chunk.js"
  },
  {
    "revision": "20a9ade82222e877aa03",
    "url": "/static/js/3.b007ca56.chunk.js"
  },
  {
    "revision": "96e27c89f32df4ccd462",
    "url": "/static/js/30.509e1090.chunk.js"
  },
  {
    "revision": "d3c2c1508b655332d749",
    "url": "/static/js/31.5be10f52.chunk.js"
  },
  {
    "revision": "ad88b6f2122aea0c03f1",
    "url": "/static/js/32.28726265.chunk.js"
  },
  {
    "revision": "c3fc35ee4e078486fc84",
    "url": "/static/js/33.598a638c.chunk.js"
  },
  {
    "revision": "d423e5ba03bbfea5c35d",
    "url": "/static/js/34.db4b28c9.chunk.js"
  },
  {
    "revision": "61053de851b02b7cc953",
    "url": "/static/js/35.cb8040ed.chunk.js"
  },
  {
    "revision": "414232c02708def07f9c",
    "url": "/static/js/36.ea6924a8.chunk.js"
  },
  {
    "revision": "e87cea5e1333cc33de7b",
    "url": "/static/js/37.580355d4.chunk.js"
  },
  {
    "revision": "f68f53551bdc24e124af",
    "url": "/static/js/38.49197172.chunk.js"
  },
  {
    "revision": "92440f1fcb9043ea661f",
    "url": "/static/js/39.61a14c47.chunk.js"
  },
  {
    "revision": "19d48cc70e5e052eb1cc",
    "url": "/static/js/4.b4569ed8.chunk.js"
  },
  {
    "revision": "8918284d41b35ec86678",
    "url": "/static/js/40.b9dd4287.chunk.js"
  },
  {
    "revision": "394149db7b9d627dc3b3",
    "url": "/static/js/41.31694aa3.chunk.js"
  },
  {
    "revision": "577d575a2b9edeab16a8",
    "url": "/static/js/42.7726f1ba.chunk.js"
  },
  {
    "revision": "10922035b91cd4737591",
    "url": "/static/js/43.194c3021.chunk.js"
  },
  {
    "revision": "1cf97833845ad85105bc",
    "url": "/static/js/44.22ecc2a6.chunk.js"
  },
  {
    "revision": "928d0f10a43768bdf768",
    "url": "/static/js/45.a1b8d6a5.chunk.js"
  },
  {
    "revision": "046e5490bd767af925b9",
    "url": "/static/js/46.c04e4882.chunk.js"
  },
  {
    "revision": "78cd4d3d5c7f065d435f",
    "url": "/static/js/47.610f3b54.chunk.js"
  },
  {
    "revision": "3f815c0ab9fc251ef7d9",
    "url": "/static/js/48.46a2d26f.chunk.js"
  },
  {
    "revision": "e712c9dc870243b8ae6b",
    "url": "/static/js/49.be219c21.chunk.js"
  },
  {
    "revision": "0b934456484dfedb13a0",
    "url": "/static/js/5.d75cd4c2.chunk.js"
  },
  {
    "revision": "9ca7f7e44c013707d629",
    "url": "/static/js/50.09b3a605.chunk.js"
  },
  {
    "revision": "63f4706f766c986bf6a4",
    "url": "/static/js/51.29d6fc6e.chunk.js"
  },
  {
    "revision": "20a52be4a806580b3990",
    "url": "/static/js/52.89882ce7.chunk.js"
  },
  {
    "revision": "c9a3977181b3a9bc43a7",
    "url": "/static/js/53.68010f8a.chunk.js"
  },
  {
    "revision": "c864c102e4fb3f0b1afb",
    "url": "/static/js/54.5385dfc0.chunk.js"
  },
  {
    "revision": "70fc81f37c9d2e55ee6a",
    "url": "/static/js/55.fe249991.chunk.js"
  },
  {
    "revision": "2d82d59252581c830eb4",
    "url": "/static/js/56.9fee8530.chunk.js"
  },
  {
    "revision": "e5a5addc3493578bfb31",
    "url": "/static/js/57.4655ea59.chunk.js"
  },
  {
    "revision": "9a93993f295fc601a54e",
    "url": "/static/js/58.445d6bde.chunk.js"
  },
  {
    "revision": "0766b0a8b0754f89f115",
    "url": "/static/js/59.010f8bb1.chunk.js"
  },
  {
    "revision": "57ca85f712b0289d820b",
    "url": "/static/js/6.724f04df.chunk.js"
  },
  {
    "revision": "be84567c92ee5f4fe509",
    "url": "/static/js/60.12fd5997.chunk.js"
  },
  {
    "revision": "8a62df163d3a270bcf56",
    "url": "/static/js/61.d5a02085.chunk.js"
  },
  {
    "revision": "8520e317e5308b9c2da2",
    "url": "/static/js/62.0ecaa635.chunk.js"
  },
  {
    "revision": "a9da65b36f39d1e8fee3",
    "url": "/static/js/63.fa30323c.chunk.js"
  },
  {
    "revision": "917c8ed6decdb0cb132b",
    "url": "/static/js/64.62c0ccb6.chunk.js"
  },
  {
    "revision": "26d9b7a2f445a8458e98",
    "url": "/static/js/65.3bcc3972.chunk.js"
  },
  {
    "revision": "c28c249c102faa937ab4",
    "url": "/static/js/66.8c621261.chunk.js"
  },
  {
    "revision": "9db4ab82725d2250f2a7",
    "url": "/static/js/67.f3c1d48f.chunk.js"
  },
  {
    "revision": "f03c1f18a06634229c73",
    "url": "/static/js/68.0a8b90ed.chunk.js"
  },
  {
    "revision": "f30ca4b979e6e169c597",
    "url": "/static/js/69.cc554fa9.chunk.js"
  },
  {
    "revision": "43f97f205e099bded51c",
    "url": "/static/js/7.5806e20b.chunk.js"
  },
  {
    "revision": "bbd443c013fc06642110",
    "url": "/static/js/70.dd4e02ea.chunk.js"
  },
  {
    "revision": "c588ad06e056c0507744",
    "url": "/static/js/71.0801e90f.chunk.js"
  },
  {
    "revision": "d3b59c21885acac73759",
    "url": "/static/js/72.4c6cd172.chunk.js"
  },
  {
    "revision": "78d6257edd1fb612b8b5",
    "url": "/static/js/73.6714acdf.chunk.js"
  },
  {
    "revision": "3f85eb7e51b1a7b9f290",
    "url": "/static/js/74.70a93426.chunk.js"
  },
  {
    "revision": "ed81e04f948ab3101336",
    "url": "/static/js/75.6a50d1b0.chunk.js"
  },
  {
    "revision": "7f9213e0ad8b68dbc384",
    "url": "/static/js/76.6646110c.chunk.js"
  },
  {
    "revision": "1a7238df54475f25d13b",
    "url": "/static/js/77.2df067e1.chunk.js"
  },
  {
    "revision": "2025cd489e1bf166cf43",
    "url": "/static/js/78.a46aed44.chunk.js"
  },
  {
    "revision": "e2a7c95473a04bfc2e28",
    "url": "/static/js/79.8ed88bca.chunk.js"
  },
  {
    "revision": "a357638d326fe88c7240",
    "url": "/static/js/8.5601ac54.chunk.js"
  },
  {
    "revision": "cbeff15243296aa8ca57",
    "url": "/static/js/80.09a32966.chunk.js"
  },
  {
    "revision": "e585cc1da1a0cbf81422",
    "url": "/static/js/81.16bb70e8.chunk.js"
  },
  {
    "revision": "0aba2eab9ea3ab82240e",
    "url": "/static/js/82.8039e8f8.chunk.js"
  },
  {
    "revision": "318d995d247111caa829",
    "url": "/static/js/83.5e22d566.chunk.js"
  },
  {
    "revision": "f90c2a018997c9095a4d",
    "url": "/static/js/9.8db07a68.chunk.js"
  },
  {
    "revision": "3ea3e53d8944f64ec47c",
    "url": "/static/js/main.3e413cc9.chunk.js"
  },
  {
    "revision": "86ba7e093379cf4e34b1",
    "url": "/static/js/runtime-main.91a4e25e.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b23df4db71a29dbb733a0e555a7db8f9",
    "url": "/static/media/feather.b23df4db.svg"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);