self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "20fb2a0f1c8576860eaa808e38550fd4",
    "url": "/index.html"
  },
  {
    "revision": "049efeb33b242a00216a",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "6095b65062af79b1cde0",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "fbbf06af4fd41b1d8b8a",
    "url": "/static/css/14.2994243c.chunk.css"
  },
  {
    "revision": "97114d83e7e00c093000",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "152d5ec98b914f660819",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "049efeb33b242a00216a",
    "url": "/static/js/0.168db230.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.168db230.chunk.js.LICENSE.txt"
  },
  {
    "revision": "71d1dc5c3c0104aca421",
    "url": "/static/js/1.c155c190.chunk.js"
  },
  {
    "revision": "3a7da892000110a5d01e",
    "url": "/static/js/10.82022fe3.chunk.js"
  },
  {
    "revision": "6095b65062af79b1cde0",
    "url": "/static/js/13.066f9988.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.066f9988.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fbbf06af4fd41b1d8b8a",
    "url": "/static/js/14.f6df607f.chunk.js"
  },
  {
    "revision": "97114d83e7e00c093000",
    "url": "/static/js/15.89626839.chunk.js"
  },
  {
    "revision": "8b0fe3bb731c8b4ab13c",
    "url": "/static/js/16.2d275382.chunk.js"
  },
  {
    "revision": "86c2c0ad7aa5430e5215",
    "url": "/static/js/17.abce4b8a.chunk.js"
  },
  {
    "revision": "48ba362b2a75b0872232",
    "url": "/static/js/18.e5036076.chunk.js"
  },
  {
    "revision": "37f44ba3470dd97cced2",
    "url": "/static/js/19.7264e05a.chunk.js"
  },
  {
    "revision": "27151a54beaf5df8c2a5",
    "url": "/static/js/2.90634f07.chunk.js"
  },
  {
    "revision": "e830ac40385c71914331",
    "url": "/static/js/20.7b779ee3.chunk.js"
  },
  {
    "revision": "a1d545b355f4c17ce2d1",
    "url": "/static/js/21.1b6ff3f1.chunk.js"
  },
  {
    "revision": "6653bc6dfc058e6eac09",
    "url": "/static/js/22.b79142b4.chunk.js"
  },
  {
    "revision": "f5ba753491bd654c032c",
    "url": "/static/js/23.497f0cb8.chunk.js"
  },
  {
    "revision": "a7065ef6ed7d722d428b",
    "url": "/static/js/24.3520e491.chunk.js"
  },
  {
    "revision": "11f7abf8afd4ba39bcdc",
    "url": "/static/js/25.53dbac94.chunk.js"
  },
  {
    "revision": "fdbd83b70c2c6555e390",
    "url": "/static/js/26.e1b698d8.chunk.js"
  },
  {
    "revision": "6dfd036d0ab81e637ff5",
    "url": "/static/js/27.a92a6093.chunk.js"
  },
  {
    "revision": "d44b5267d90cc14a783f",
    "url": "/static/js/28.9d2f3379.chunk.js"
  },
  {
    "revision": "f6fb0589038fa322f504",
    "url": "/static/js/29.75e0dfd3.chunk.js"
  },
  {
    "revision": "686b0dbc0dcaf0cbb6a6",
    "url": "/static/js/3.99966559.chunk.js"
  },
  {
    "revision": "cac3cc4a40372f3af446",
    "url": "/static/js/30.3c9324ef.chunk.js"
  },
  {
    "revision": "90263673c8aa786c0c31",
    "url": "/static/js/31.713df257.chunk.js"
  },
  {
    "revision": "cdf510d6c09bc74a7052",
    "url": "/static/js/32.6f8e4cf2.chunk.js"
  },
  {
    "revision": "cc2c2bc1bbf3c8ee1a5a",
    "url": "/static/js/33.8ba302a6.chunk.js"
  },
  {
    "revision": "795f57c715ecf5e14522",
    "url": "/static/js/34.762df08c.chunk.js"
  },
  {
    "revision": "cf657469926b4800042d",
    "url": "/static/js/35.d63eed84.chunk.js"
  },
  {
    "revision": "dd367a134d99d6a0d716",
    "url": "/static/js/36.71366ffb.chunk.js"
  },
  {
    "revision": "c0f42429d33dcdf1644c",
    "url": "/static/js/37.f66b7d4c.chunk.js"
  },
  {
    "revision": "199e7197af67c154e1b1",
    "url": "/static/js/38.436ab0e9.chunk.js"
  },
  {
    "revision": "81f05049a67df6227f40",
    "url": "/static/js/39.99d503a0.chunk.js"
  },
  {
    "revision": "1bb5da57c18e8034d6a0",
    "url": "/static/js/4.15455a9e.chunk.js"
  },
  {
    "revision": "d2edaba112f59a8bcf00",
    "url": "/static/js/40.4f1ed2ce.chunk.js"
  },
  {
    "revision": "3e6cdc2a5655fbd8d4f2",
    "url": "/static/js/41.5e4ebea7.chunk.js"
  },
  {
    "revision": "dfacb6135ac43c219f50",
    "url": "/static/js/42.fdc54956.chunk.js"
  },
  {
    "revision": "5d5e827f40c633e24441",
    "url": "/static/js/43.90604e30.chunk.js"
  },
  {
    "revision": "819dc9cf5926868365a3",
    "url": "/static/js/44.93e3cf70.chunk.js"
  },
  {
    "revision": "cc88f5a6bb86d8e3d405",
    "url": "/static/js/45.93e63c85.chunk.js"
  },
  {
    "revision": "6ce897f757f03652c858",
    "url": "/static/js/46.ca37f343.chunk.js"
  },
  {
    "revision": "388b7cc72741458f27a3",
    "url": "/static/js/47.a682fe49.chunk.js"
  },
  {
    "revision": "f986bceb77163f8c8b87",
    "url": "/static/js/48.3c601380.chunk.js"
  },
  {
    "revision": "836ea337e327e13b9db1",
    "url": "/static/js/49.421772c8.chunk.js"
  },
  {
    "revision": "ce244aa6c100f0a13fd2",
    "url": "/static/js/5.d7da7eda.chunk.js"
  },
  {
    "revision": "5edc5280606718982fa9",
    "url": "/static/js/50.d8d5a65a.chunk.js"
  },
  {
    "revision": "600b0016287cc4be321c",
    "url": "/static/js/51.508a8942.chunk.js"
  },
  {
    "revision": "a77b0f40af463eb103ee",
    "url": "/static/js/52.2b5950c1.chunk.js"
  },
  {
    "revision": "c3b4dbbaa75d6bbf40d3",
    "url": "/static/js/53.e9380bed.chunk.js"
  },
  {
    "revision": "d3635c30765c5af4daf0",
    "url": "/static/js/54.5c4015ab.chunk.js"
  },
  {
    "revision": "b82fc6277bcaebce56a8",
    "url": "/static/js/55.4f57d62b.chunk.js"
  },
  {
    "revision": "2c434e71ad51a1987f29",
    "url": "/static/js/56.2bc079aa.chunk.js"
  },
  {
    "revision": "12b9019a88bf3f589677",
    "url": "/static/js/57.af01f19c.chunk.js"
  },
  {
    "revision": "c4bedca6a7a713218dc9",
    "url": "/static/js/58.180eed45.chunk.js"
  },
  {
    "revision": "ded01d7e818b50e1fbcd",
    "url": "/static/js/59.77990051.chunk.js"
  },
  {
    "revision": "8fea6d582efd5d09b754",
    "url": "/static/js/6.8a511dd2.chunk.js"
  },
  {
    "revision": "69b6a0a765fc57aa8bf9",
    "url": "/static/js/60.57ac336a.chunk.js"
  },
  {
    "revision": "6b08b0fc8e4a10f87faa",
    "url": "/static/js/61.0fa8d36f.chunk.js"
  },
  {
    "revision": "7e82c1bbeaff5424ac80",
    "url": "/static/js/62.a2b13920.chunk.js"
  },
  {
    "revision": "2eae4626141ca70a8e51",
    "url": "/static/js/63.bc8f717d.chunk.js"
  },
  {
    "revision": "9d7b3b03d84bb17accd3",
    "url": "/static/js/64.666349b0.chunk.js"
  },
  {
    "revision": "017927f8975d5145ac56",
    "url": "/static/js/65.dbc8cbdd.chunk.js"
  },
  {
    "revision": "b97f630aca46fe70a0c5",
    "url": "/static/js/66.cf3ad29b.chunk.js"
  },
  {
    "revision": "012191bb4b237fcc31e4",
    "url": "/static/js/67.d021da12.chunk.js"
  },
  {
    "revision": "cac2a55914e61b8a5439",
    "url": "/static/js/68.ed520a47.chunk.js"
  },
  {
    "revision": "9f0ad2953e430ab0ff0e",
    "url": "/static/js/69.2091cace.chunk.js"
  },
  {
    "revision": "cf8202665d3b25d06b29",
    "url": "/static/js/7.defc2102.chunk.js"
  },
  {
    "revision": "a0667cb72e99c9ccdb67",
    "url": "/static/js/70.d8e0c3e3.chunk.js"
  },
  {
    "revision": "8eb230f5efd3f5c7d0d1",
    "url": "/static/js/71.0ba7dc96.chunk.js"
  },
  {
    "revision": "eebf6e9f0bb1910c4484",
    "url": "/static/js/72.ed64c5f7.chunk.js"
  },
  {
    "revision": "363251e44cdefe62a3a7",
    "url": "/static/js/73.e87aeaac.chunk.js"
  },
  {
    "revision": "fc28947284e5479cc7ca",
    "url": "/static/js/74.529d728c.chunk.js"
  },
  {
    "revision": "5de1eeb84188c1775a82",
    "url": "/static/js/75.ee402837.chunk.js"
  },
  {
    "revision": "b154305783c15ececa92",
    "url": "/static/js/76.89f023e5.chunk.js"
  },
  {
    "revision": "ff7a80e1d03dc5058a94",
    "url": "/static/js/77.9a089bc8.chunk.js"
  },
  {
    "revision": "d764430ba18e09eaa141",
    "url": "/static/js/78.766e2fde.chunk.js"
  },
  {
    "revision": "ac257f0d7560fc82c365",
    "url": "/static/js/79.0824114d.chunk.js"
  },
  {
    "revision": "8785745b1f8bfb46acad",
    "url": "/static/js/8.e54d2d07.chunk.js"
  },
  {
    "revision": "76713d617db829d1616f",
    "url": "/static/js/80.a9fc966a.chunk.js"
  },
  {
    "revision": "c3d7728c79f626ba73fa",
    "url": "/static/js/81.ef1e408f.chunk.js"
  },
  {
    "revision": "9bc5b064a4ef5b754aaf",
    "url": "/static/js/82.f344cda7.chunk.js"
  },
  {
    "revision": "9b60054864d99a9dc275",
    "url": "/static/js/83.d970c122.chunk.js"
  },
  {
    "revision": "567c280b26499ce457fa",
    "url": "/static/js/9.3adfcf8f.chunk.js"
  },
  {
    "revision": "152d5ec98b914f660819",
    "url": "/static/js/main.2aed1549.chunk.js"
  },
  {
    "revision": "b5ec378becf978469827",
    "url": "/static/js/runtime-main.6fb7bf7a.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b23df4db71a29dbb733a0e555a7db8f9",
    "url": "/static/media/feather.b23df4db.svg"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);