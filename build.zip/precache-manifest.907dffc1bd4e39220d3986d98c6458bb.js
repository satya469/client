self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "911edfa480de9ccaeffcef0b5fd6606e",
    "url": "/index.html"
  },
  {
    "revision": "dda7ddd5ea63ed94fdbc",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "8778222075c1c2fe08e1",
    "url": "/static/css/12.2e947bf2.chunk.css"
  },
  {
    "revision": "7d431a00722ce271ffd2",
    "url": "/static/css/14.db940404.chunk.css"
  },
  {
    "revision": "d1e1f9398b53bb4e080c",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "8f56446483fa274a7b65",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "dda7ddd5ea63ed94fdbc",
    "url": "/static/js/0.046bbe8c.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.046bbe8c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0de9fa6447d51648ba42",
    "url": "/static/js/1.cb828f96.chunk.js"
  },
  {
    "revision": "8778222075c1c2fe08e1",
    "url": "/static/js/12.76040ba9.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/12.76040ba9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "49d299f8c65e0d17c936",
    "url": "/static/js/13.9bb61a67.chunk.js"
  },
  {
    "revision": "7d431a00722ce271ffd2",
    "url": "/static/js/14.40885425.chunk.js"
  },
  {
    "revision": "d1e1f9398b53bb4e080c",
    "url": "/static/js/15.eee12485.chunk.js"
  },
  {
    "revision": "54d614d964d0cc4498bd",
    "url": "/static/js/16.48ed0bc6.chunk.js"
  },
  {
    "revision": "82c5f723bcf33775155d",
    "url": "/static/js/17.e3a8377a.chunk.js"
  },
  {
    "revision": "e1d4bdb0ace376750533",
    "url": "/static/js/18.2e08b467.chunk.js"
  },
  {
    "revision": "f3d2e9dc268f73c3a670",
    "url": "/static/js/19.45cd4a9c.chunk.js"
  },
  {
    "revision": "4489f296e050805180b3",
    "url": "/static/js/2.04c65c44.chunk.js"
  },
  {
    "revision": "867e866767c91494d6dc",
    "url": "/static/js/20.5d4a67a4.chunk.js"
  },
  {
    "revision": "85d18b5614afe2e542a3",
    "url": "/static/js/21.f947597d.chunk.js"
  },
  {
    "revision": "8ca50643fd66c4f5ff55",
    "url": "/static/js/22.5462d8af.chunk.js"
  },
  {
    "revision": "ee31efc4594a9a9bf508",
    "url": "/static/js/23.a394feb7.chunk.js"
  },
  {
    "revision": "69d1acf62612df0d3983",
    "url": "/static/js/24.421f886e.chunk.js"
  },
  {
    "revision": "b54ebf29c8510267f9cd",
    "url": "/static/js/25.100029a6.chunk.js"
  },
  {
    "revision": "c2c912adf1fef63c7e74",
    "url": "/static/js/26.544b8b81.chunk.js"
  },
  {
    "revision": "205909c20c6dc782b47b",
    "url": "/static/js/27.faa5a7b8.chunk.js"
  },
  {
    "revision": "d53c47e2b830b8a01e89",
    "url": "/static/js/28.1bc2076d.chunk.js"
  },
  {
    "revision": "ab93cc41632bb750a2cf",
    "url": "/static/js/29.40229beb.chunk.js"
  },
  {
    "revision": "2841a0d13b12d7e5c607",
    "url": "/static/js/3.b5304605.chunk.js"
  },
  {
    "revision": "53aed84d5c785414e378",
    "url": "/static/js/30.5699f89b.chunk.js"
  },
  {
    "revision": "857a6a37f20c8fe03664",
    "url": "/static/js/31.dbc20a30.chunk.js"
  },
  {
    "revision": "40ca879d1ce0431f3762",
    "url": "/static/js/32.779172bb.chunk.js"
  },
  {
    "revision": "ec28b010d8ef36c5252e",
    "url": "/static/js/33.2f8bf5fb.chunk.js"
  },
  {
    "revision": "505bf0fb66550bd16dc8",
    "url": "/static/js/34.2ba0c7b4.chunk.js"
  },
  {
    "revision": "9e5af54b79c3ce75114c",
    "url": "/static/js/35.53c79abe.chunk.js"
  },
  {
    "revision": "bc016e919ce132ff1279",
    "url": "/static/js/36.55b418fa.chunk.js"
  },
  {
    "revision": "be9f36ccffc0f5b7e643",
    "url": "/static/js/37.65335c06.chunk.js"
  },
  {
    "revision": "95a695bce0ba402bd587",
    "url": "/static/js/38.6cfc2b27.chunk.js"
  },
  {
    "revision": "a15fb9cd84b08a9ede59",
    "url": "/static/js/39.b463b4b7.chunk.js"
  },
  {
    "revision": "47884b0485d5893a57db",
    "url": "/static/js/4.c2503032.chunk.js"
  },
  {
    "revision": "c7d8a4e6e3929410622e",
    "url": "/static/js/40.515b7f25.chunk.js"
  },
  {
    "revision": "2d2b5de67981e138346a",
    "url": "/static/js/41.0e5202ee.chunk.js"
  },
  {
    "revision": "be6a21780f0c61faf8ae",
    "url": "/static/js/42.e0a8b3a7.chunk.js"
  },
  {
    "revision": "4d101e5a2ebd266f6ac4",
    "url": "/static/js/43.d7e2f678.chunk.js"
  },
  {
    "revision": "05fa8cb37da29f4a637b",
    "url": "/static/js/44.54bda28d.chunk.js"
  },
  {
    "revision": "39e845a6cdc0bc4ee380",
    "url": "/static/js/45.e7cd78db.chunk.js"
  },
  {
    "revision": "0a5fa3918ed85dd8993e",
    "url": "/static/js/46.0dd84bb2.chunk.js"
  },
  {
    "revision": "6d9210868c1b67c6afc6",
    "url": "/static/js/47.f0dbc563.chunk.js"
  },
  {
    "revision": "93109ae0feca798ed546",
    "url": "/static/js/48.aff3dcaf.chunk.js"
  },
  {
    "revision": "452a3a880284ebddb5ec",
    "url": "/static/js/49.2819445a.chunk.js"
  },
  {
    "revision": "5ca470ce1b6c82f075b4",
    "url": "/static/js/5.09ae0a8c.chunk.js"
  },
  {
    "revision": "2f238a29e9221ae18803",
    "url": "/static/js/50.0e5e66dc.chunk.js"
  },
  {
    "revision": "68c797b6a17b675e2f4f",
    "url": "/static/js/51.6250a8a8.chunk.js"
  },
  {
    "revision": "dff3e3934c2138ca1c11",
    "url": "/static/js/52.3e03e423.chunk.js"
  },
  {
    "revision": "34832f7adbb970ad7d96",
    "url": "/static/js/53.b1dc4cd0.chunk.js"
  },
  {
    "revision": "9fdd6b5a5f1cf543f519",
    "url": "/static/js/54.de99f043.chunk.js"
  },
  {
    "revision": "7ca5b201168662e2d869",
    "url": "/static/js/55.7ae32309.chunk.js"
  },
  {
    "revision": "93d7588a0107c8bdece3",
    "url": "/static/js/56.b50aa396.chunk.js"
  },
  {
    "revision": "5308e606671b0bdaddd2",
    "url": "/static/js/57.17a05f94.chunk.js"
  },
  {
    "revision": "b9fba90265e1d857baff",
    "url": "/static/js/58.f5066c94.chunk.js"
  },
  {
    "revision": "3eb8d24ff60c6dbfcf82",
    "url": "/static/js/59.c6f00c28.chunk.js"
  },
  {
    "revision": "aba208f2978bed049857",
    "url": "/static/js/6.6b674eea.chunk.js"
  },
  {
    "revision": "eee0ca74fdaf57ac4882",
    "url": "/static/js/60.d4feb4c9.chunk.js"
  },
  {
    "revision": "6c8f5589779eef83e992",
    "url": "/static/js/61.3fde91c3.chunk.js"
  },
  {
    "revision": "dc7f4c77eeb2701c5bba",
    "url": "/static/js/62.4e50d414.chunk.js"
  },
  {
    "revision": "7b1f5f05f02952571c06",
    "url": "/static/js/63.e79da982.chunk.js"
  },
  {
    "revision": "57f27e62ebc3a3cb7630",
    "url": "/static/js/64.ef774a0e.chunk.js"
  },
  {
    "revision": "2bcac2b855ed57d2271b",
    "url": "/static/js/65.c09488a3.chunk.js"
  },
  {
    "revision": "695d72485fa5e5e1f7d7",
    "url": "/static/js/66.9689d2fb.chunk.js"
  },
  {
    "revision": "b4cfed19f6b00edd836e",
    "url": "/static/js/67.8ed9ab4c.chunk.js"
  },
  {
    "revision": "0a462fcf24012a6b9e01",
    "url": "/static/js/68.277ee347.chunk.js"
  },
  {
    "revision": "9dbbb19e228c1f105f2f",
    "url": "/static/js/69.64e232d5.chunk.js"
  },
  {
    "revision": "fb3a4952187185ee0a7e",
    "url": "/static/js/7.52ab4832.chunk.js"
  },
  {
    "revision": "cd03cbb3907e8b4b9ebe",
    "url": "/static/js/70.024c2536.chunk.js"
  },
  {
    "revision": "f9c09eb1d59243970216",
    "url": "/static/js/71.d1620102.chunk.js"
  },
  {
    "revision": "96db9ab7e97464450949",
    "url": "/static/js/72.5fc6670b.chunk.js"
  },
  {
    "revision": "1a817f14b4d074a03145",
    "url": "/static/js/73.083f2077.chunk.js"
  },
  {
    "revision": "c0a03c6b53ce567d556f",
    "url": "/static/js/74.eb49d2ac.chunk.js"
  },
  {
    "revision": "c41a220887c02bc0a1df",
    "url": "/static/js/75.9094fcf0.chunk.js"
  },
  {
    "revision": "6c64852b3495b82db00c",
    "url": "/static/js/76.82bc34ad.chunk.js"
  },
  {
    "revision": "01fbd9eb30637b890dfc",
    "url": "/static/js/77.d63f8aef.chunk.js"
  },
  {
    "revision": "c04ffa913242845c1038",
    "url": "/static/js/78.069451be.chunk.js"
  },
  {
    "revision": "e29e4ddc30f5635b3ba5",
    "url": "/static/js/79.f0b537d1.chunk.js"
  },
  {
    "revision": "03d1e7b47bf1b4475acd",
    "url": "/static/js/8.c39bd95d.chunk.js"
  },
  {
    "revision": "c53689a6f47029f84bf1",
    "url": "/static/js/80.02959f75.chunk.js"
  },
  {
    "revision": "9aefd63cdf4348544e54",
    "url": "/static/js/9.8a18417a.chunk.js"
  },
  {
    "revision": "8f56446483fa274a7b65",
    "url": "/static/js/main.e8f4d7cf.chunk.js"
  },
  {
    "revision": "51c3ec845ca628940394",
    "url": "/static/js/runtime-main.f8756725.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);